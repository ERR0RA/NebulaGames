(function() {
  if (document.getElementById('sparx-solver-box')) return;

  var host = location.hostname.toLowerCase();
  var isSparxReader = host === 'reader.sparx-learning.com';
  var isMusicFirst = host === 'musicfirst.com' || host.endsWith('.musicfirst.com');
  var isStudyMode = isSparxReader || isMusicFirst;

  var box = document.createElement('div'); box.id = 'sparx-solver-box';
  var inner = document.createElement('div'); inner.id = 'sparx-inner';
  inner.innerHTML = isStudyMode
    ? '<div class="sparx-header"><span class="sparx-header-title">' + (isMusicFirst ? 'MusicFirst Study Helper' : 'Sparx Reader Helper') + '</span></div><div class="sparx-section"><div class="sparx-label">' + (isMusicFirst ? 'MusicFirst mode' : 'Reader mode') + '</div><div class="sparx-question-text has-text expanded" id="sparx-q-display">Study support mode is enabled. Final-answer and auto-fill tools are disabled here.</div></div><button class="sparx-rescan" id="sparx-scan-btn">Scan visible text</button><button class="sparx-rescan" id="sparx-reader-extract-btn">Show full scanned extract</button><div class="sparx-reader-search"><div class="sparx-label">Find answer evidence</div><input id="sparx-reader-query" type="text" placeholder="Type a few words from the question"><select id="sparx-reader-qtype"><option value="general">Question type: General</option><option value="inference">Question type: Inference</option><option value="vocab">Question type: Vocabulary</option><option value="tone">Question type: Mood / Tone</option><option value="purpose">Question type: Purpose / Effect</option></select><label class="sparx-reader-check"><input id="sparx-reader-auto-evidence" type="checkbox"> Auto-refresh evidence while typing</label><button class="sparx-solve-btn" id="sparx-reader-highlight-btn">Highlight answer evidence</button><button class="sparx-solve-btn" id="sparx-reader-full-highlight-btn">Full extract + answer highlights</button><button class="sparx-solve-btn" id="sparx-reader-map-btn">Evidence map</button><textarea id="sparx-reader-choices" placeholder="Optional: paste each answer choice on a new line"></textarea><button class="sparx-solve-btn" id="sparx-reader-choices-btn">Compare choice evidence</button><textarea id="sparx-reader-reasoning" placeholder="Optional: write your chosen answer and why"></textarea><button class="sparx-solve-btn" id="sparx-reader-reason-btn">Check my reasoning</button></div><button class="sparx-solve-btn" id="sparx-reader-summary-btn">Detailed summary</button><button class="sparx-solve-btn" id="sparx-reader-help-btn"><span class="sparx-neon-logo" aria-hidden="true"></span>' + (isMusicFirst ? 'Study help for MusicFirst' : 'Solve in Reader') + '</button><button class="sparx-rescan" id="sparx-reader-stats-btn">Performance stats</button><div class="sparx-answer visible" id="sparx-answer-box"><div class="sparx-label">Disclaimer</div><div class="sparx-answer-text" id="sparx-answer-text">This helper can explain the text, define vocabulary, show likely answer evidence lines, and summarise the extract. It will not provide final answers to assigned homework questions.</div></div><div id="sparx-history"></div>'
    : '<div class="sparx-header"><span class="sparx-header-title">Sparx Solver</span></div><div class="sparx-section"><div class="sparx-label">Detected Question</div><div class="sparx-question-text" id="sparx-q-display">Click Scan to read the question...</div></div><button class="sparx-rescan" id="sparx-scan-btn">Scan page for question</button><button class="sparx-solve-btn" id="sparx-solve-btn">Solve with AI</button><button class="sparx-autofill-btn" id="sparx-autofill-btn">Auto-fill</button><div class="sparx-answer" id="sparx-answer-box"><div class="sparx-label">Answer</div><div class="sparx-answer-text" id="sparx-answer-text"></div></div><button class="sparx-hist-toggle" id="sparx-hist-toggle">Show history</button><button class="sparx-hist-clear" id="sparx-hist-clear" style="display:none;">Clear history</button><div id="sparx-history"></div>';
  box.appendChild(inner);

  var toggleBtn = document.createElement('button'); toggleBtn.id = 'sparx-solver-btn'; toggleBtn.textContent = 'S'; toggleBtn.title = 'Sparx Solver';

  document.body.appendChild(box);
  document.body.appendChild(toggleBtn);

  if (isStudyMode) {
    var readerText = '';
    var readerQuality = { score: 0, notes: ['Scan text first.'], words: 0 };
    var readerStats = { scans: 0, highlights: 0, aiCalls: 0, aiErrors: 0, lastAction: 'idle', lastMs: 0 };
    box.classList.add('sparx-reader-mode');
    toggleBtn.textContent = isMusicFirst ? 'M' : 'R';
    toggleBtn.title = isMusicFirst ? 'MusicFirst Study Helper' : 'Sparx Reader Helper';
    toggleBtn.addEventListener('click', function() {
      box.classList.toggle('open');
      if (box.classList.contains('open')) scanReaderPage();
    });
    box.addEventListener('click', function(e) {
      var target = e.target;
      if (target.id === 'sparx-q-display') { e.stopPropagation(); target.classList.toggle('expanded'); return; }
      if (target.id === 'sparx-scan-btn') { e.stopPropagation(); scanReaderPage(); }
      if (target.id === 'sparx-reader-extract-btn') { e.stopPropagation(); showReaderExtract(); }
      if (target.id === 'sparx-reader-highlight-btn') { e.stopPropagation(); highlightReaderSentence(); }
      if (target.id === 'sparx-reader-full-highlight-btn') { e.stopPropagation(); highlightReaderSentence(true); }
      if (target.id === 'sparx-reader-map-btn') { e.stopPropagation(); showEvidenceMap(); }
      if (target.id === 'sparx-reader-choices-btn') { e.stopPropagation(); compareReaderChoices(); }
      if (target.id === 'sparx-reader-reason-btn') { e.stopPropagation(); checkReaderReasoning(); }
      if (target.id === 'sparx-reader-summary-btn') { e.stopPropagation(); getReaderSummary(); }
      if (target.id === 'sparx-reader-help-btn') { e.stopPropagation(); getReaderStudyHelp(); }
      if (target.id === 'sparx-reader-stats-btn') { e.stopPropagation(); showReaderStats(); }
    }, true);
    var readerAutoTimer = null;
    document.getElementById('sparx-reader-query').addEventListener('input', function() {
      var auto = document.getElementById('sparx-reader-auto-evidence');
      if (!auto || !auto.checked) return;
      clearTimeout(readerAutoTimer);
      readerAutoTimer = setTimeout(function() { highlightReaderSentence(true); }, 450);
    });
    function scanReaderPage() {
      var t0 = Date.now();
      var display = document.getElementById('sparx-q-display');
      var answer = document.getElementById('sparx-answer-text');
      var main = document.querySelector('main') || document.querySelector('[role="main"]') || document.body;
      var text = cleanReaderText(main.innerText || '');
      if (!text) {
        display.textContent = 'No readable text found on this Reader page.';
        answer.textContent = 'Try opening the reading or question area, then scan again.';
        readerText = '';
        readerQuality = { score: 0, notes: ['No readable text found.'], words: 0 };
        return;
      }
      readerText = text;
      readerQuality = assessReaderQuality(text);
      readerStats.scans += 1;
      readerStats.lastAction = 'scan';
      readerStats.lastMs = Date.now() - t0;
      display.textContent = text;
      display.classList.add('has-text', 'expanded');
      answer.textContent = 'Scanned visible text. Quality: ' + readerQuality.score + '/100. ' + readerQuality.notes.join(' ');
    }
    function assessReaderQuality(text) {
      var words = (text.match(/\b[\w'-]+\b/g) || []).length;
      var notes = [];
      var score = 100;
      if (words < 120) { score -= 35; notes.push('Passage looks short, open more text and re-scan.'); }
      if (words < 240 && words >= 120) { score -= 15; notes.push('Could use more context for stronger evidence.'); }
      if (/cookie settings|sign out|menu|feedback|dashboard|assignments|classes/i.test(text)) {
        score -= 20; notes.push('UI noise detected, scroll to passage and scan again.');
      }
      var repeated = (text.match(/\b(the|and|to|of)\b/gi) || []).length;
      if (repeated > words * 0.22) { score -= 10; notes.push('Text may be repetitive/noisy.'); }
      if (!notes.length) notes.push('Good extraction quality.');
      if (score < 0) score = 0;
      return { score: score, notes: notes, words: words };
    }
    function cleanReaderText(raw) {
      var text = (raw || '')
        .replace(/\u00a0/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

      var startPhrases = [
        'Start reading here',
        "Click here when you're ready to start reading.",
        'Click here when you are ready to start reading.'
      ];
      for (var i = 0; i < startPhrases.length; i++) {
        var idx = text.indexOf(startPhrases[i]);
        if (idx !== -1) {
          text = text.substring(idx + startPhrases[i].length).trim();
          break;
        }
      }

      text = text
        .replace(/^\d[\d,]*\s+SRP\s+/i, '')
        .replace(/\b(?:Menu|Settings|Feedback|Cookie Settings|Sign out|Switch to Sparx Maths)\b/gi, ' ')
        .replace(/\b(?:Assignments|Classes|Resources|Messages|Help Centre|Dashboard|Notifications|Profile)\b/gi, ' ')
        .replace(/\s+/g, ' ')
        .trim();

      var badLead = /^(?:[\w\s,'.:-]{0,140})?(?:Cookie Settings|Sign out|Switch to Sparx Maths)\s+/i;
      while (badLead.test(text)) text = text.replace(badLead, '').trim();
      return text;
    }
    function showReaderExtract() {
      var display = document.getElementById('sparx-q-display');
      var answer = document.getElementById('sparx-answer-text');
      if (!readerText) scanReaderPage();
      if (!readerText) return;
      display.textContent = readerText;
      display.classList.add('has-text', 'expanded');
      answer.innerHTML = '<b>Full scanned extract shown above.</b><br>This is the visible text the helper can currently read. If something is missing, open that section on the Reader page and scan again.';
    }
    function splitReaderSentences(text) {
      return text
        .replace(/\s+/g, ' ')
        .split(/(?<=[.!?])\s+|(?<=:)\s+/)
        .map(function(s) { return s.trim(); })
        .filter(function(s) { return s.length > 20; });
    }
    function keywordSet(text) {
      var stop = {
        the:1, a:1, an:1, and:1, or:1, but:1, to:1, of:1, in:1, on:1, at:1, for:1, from:1,
        with:1, by:1, is:1, are:1, was:1, were:1, be:1, been:1, being:1, it:1, this:1,
        that:1, these:1, those:1, what:1, why:1, how:1, when:1, where:1, who:1, which:1,
        does:1, do:1, did:1, can:1, could:1, would:1, should:1, question:1, answer:1,
        according:1, text:1, passage:1, story:1, sentence:1, paragraph:1, best:1, most:1,
        least:1, likely:1, true:1, false:1, mean:1, means:1, following:1, option:1, choose:1
      };
      var words = text.toLowerCase().match(/[a-z0-9']+/g) || [];
      var out = {};
      words.forEach(function(w) {
        if (w.length > 2 && !stop[w]) out[w] = (out[w] || 0) + 1;
      });
      return out;
    }
    function stemWord(word) {
      return word
        .replace(/'s$/,'')
        .replace(/ies$/,'y')
        .replace(/(ing|ed|ly|es|s)$/,'');
    }
    function sentenceTokens(sentence) {
      var raw = sentence.toLowerCase().match(/[a-z0-9']+/g) || [];
      var set = {};
      raw.forEach(function(w) {
        if (w.length > 2) {
          set[w] = 1;
          set[stemWord(w)] = 1;
        }
      });
      return set;
    }
    function getReaderQuestionType() {
      var el = document.getElementById('sparx-reader-qtype');
      return el ? el.value : 'general';
    }
    function expandTermsForType(termList) {
      var type = getReaderQuestionType();
      var extras = [];
      if (type === 'inference') extras = ['implies', 'suggests', 'hint', 'likely', 'because'];
      if (type === 'vocab') extras = ['means', 'definition', 'word', 'phrase', 'context'];
      if (type === 'tone') extras = ['mood', 'tone', 'feeling', 'attitude', 'atmosphere'];
      if (type === 'purpose') extras = ['purpose', 'effect', 'why', 'author', 'shows'];
      var merged = termList.slice();
      extras.forEach(function(x) { if (merged.indexOf(x) === -1) merged.push(x); });
      return merged;
    }
    function scoreReaderSentences(query, limit) {
      var terms = keywordSet(query);
      var termList = expandTermsForType(Object.keys(terms));
      if (!termList.length) return [];
      var sentences = splitReaderSentences(readerText);
      var docFreq = {};
      var sentenceSets = sentences.map(function(sentence) {
        var set = sentenceTokens(sentence);
        Object.keys(set).forEach(function(w) { docFreq[w] = (docFreq[w] || 0) + 1; });
        return set;
      });
      var ranked = [];
      sentences.forEach(function(sentence, idx) {
        var lower = sentence.toLowerCase();
        var score = 0;
        var matched = [];
        var set = sentenceSets[idx];
        termList.forEach(function(term) {
          var stem = stemWord(term);
          if (set[term] || set[stem] || lower.indexOf(term) !== -1) {
            var rarity = Math.log((sentences.length + 1) / ((docFreq[term] || docFreq[stem] || 1) + 1)) + 1;
            var weight = (term.length > 5 ? 2.2 : 1.2) * rarity;
            score += weight;
            matched.push(term);
          }
        });
        if (lower.indexOf(query.toLowerCase()) !== -1) score += 8;
        var orderedHits = 0;
        for (var t = 0; t < termList.length - 1; t++) {
          if (lower.indexOf(termList[t]) !== -1 && lower.indexOf(termList[t + 1]) !== -1) orderedHits += 1;
        }
        score += orderedHits * 0.8;
        if (/cookie settings|sign out|switch to sparx|menu settings|feedback/i.test(sentence)) score -= 100;
        if (matched.length < Math.min(2, termList.length)) score *= 0.35;
        if (score > 0) ranked.push({ sentence: sentence, index: idx, score: score, matched: matched });
      });
      ranked.sort(function(a, b) { return b.score - a.score; });
      return ranked.slice(0, limit || 5);
    }
    function showEvidenceMap() {
      var answer = document.getElementById('sparx-answer-text');
      var input = document.getElementById('sparx-reader-query');
      if (!readerText) scanReaderPage();
      if (!readerText) return;
      var query = (input && input.value || '').trim();
      if (!query) {
        answer.textContent = 'Type question words first, then click Evidence map.';
        return;
      }
      var picks = scoreReaderSentences(query, 8);
      if (!picks.length) {
        answer.textContent = 'No evidence map yet. Try a shorter query or re-scan.';
        return;
      }
      var html = '<b>Evidence map</b><br>';
      picks.forEach(function(p, idx) {
        html += '<br><b>#' + (idx + 1) + ' (line ' + (p.index + 1) + ')</b> ' + esc(p.sentence);
        if (p.matched && p.matched.length) html += '<br><span class="sparx-reader-meta">matched: ' + esc(p.matched.join(', ')) + '</span>';
      });
      answer.innerHTML = html;
    }
    function showReaderStats() {
      var answer = document.getElementById('sparx-answer-text');
      var html = '<b>Performance stats</b><br>';
      html += '<br>Scans: ' + readerStats.scans;
      html += '<br>Highlights: ' + readerStats.highlights;
      html += '<br>AI calls: ' + readerStats.aiCalls;
      html += '<br>AI errors: ' + readerStats.aiErrors;
      html += '<br>Last action: ' + readerStats.lastAction + ' (' + readerStats.lastMs + 'ms)';
      html += '<br>Extract quality: ' + readerQuality.score + '/100 (' + readerQuality.words + ' words)';
      html += '<br><span class="sparx-reader-meta">' + esc(readerQuality.notes.join(' ')) + '</span>';
      answer.innerHTML = html;
    }
    function highlightReaderSentence(showFullExtract) {
      var t0 = Date.now();
      var display = document.getElementById('sparx-q-display');
      var answer = document.getElementById('sparx-answer-text');
      var input = document.getElementById('sparx-reader-query');
      if (!readerText) scanReaderPage();
      if (!readerText) return;
      var query = (input && input.value || '').trim();
      if (!query) {
        answer.textContent = 'Type a few words from the question first.';
        return;
      }
      var terms = keywordSet(query);
      var termList = Object.keys(terms);
      if (!termList.length) {
        answer.textContent = 'Use more specific words from the question.';
        return;
      }
      var sentences = splitReaderSentences(readerText);
      var ranked = scoreReaderSentences(query, 5);
      if (!ranked.length) {
        answer.textContent = 'No close evidence line found. Try fewer words, or scan again after opening the relevant part of the text.';
        return;
      }
      var picks = ranked.slice(0, 5);
      readerStats.highlights += 1;
      readerStats.lastAction = 'highlight';
      readerStats.lastMs = Date.now() - t0;
      var picked = {};
      picks.forEach(function(p) { picked[p.index] = true; });
      var first = picks.reduce(function(min, p) { return Math.min(min, p.index); }, picks[0].index);
      var last = picks.reduce(function(max, p) { return Math.max(max, p.index); }, picks[0].index);
      var start = showFullExtract ? 0 : Math.max(0, first - 2);
      var end = showFullExtract ? sentences.length - 1 : Math.min(sentences.length - 1, last + 2);
      var html = '';
      for (var i = start; i <= end; i++) {
        if (picked[i]) html += '<mark class="sparx-reader-mark">' + esc(sentences[i]) + '</mark> ';
        else html += esc(sentences[i]) + ' ';
      }
      display.innerHTML = html.trim();
      display.classList.add('has-text', 'expanded');
      var confidence = 'medium';
      var confidenceReason = 'Balanced match quality.';
      var top = picks[0];
      var second = picks.length > 1 ? picks[1] : null;
      var topScore = top && typeof top.score === 'number' ? top.score : 0;
      var secondScore = second && typeof second.score === 'number' ? second.score : 0;
      var gap = topScore - secondScore;
      var termsMatched = (top && top.matched ? top.matched.length : 0);
      if (topScore >= 10 && gap >= 3 && termsMatched >= 3) {
        confidence = 'high';
        confidenceReason = 'Top line clearly outranks other candidates.';
      } else if (topScore < 5 || gap < 1.2 || termsMatched < 2) {
        confidence = 'low';
        confidenceReason = 'Close or weak matches; compare multiple lines.';
      }
      var answerHtml = '<b>Top evidence match</b><br>' + esc(picks[0].sentence);
      if (picks[0].matched && picks[0].matched.length) answerHtml += '<br><span class="sparx-reader-meta">matched: ' + esc(picks[0].matched.join(', ')) + '</span>';
      answerHtml += '<br><span class="sparx-reader-meta">confidence: ' + confidence.toUpperCase() + ' â€¢ ' + esc(confidenceReason) + '</span>';
      if (readerQuality.score < 70) answerHtml += '<br><span class="sparx-reader-meta">warning: extract quality is low (' + readerQuality.score + '/100). Re-scan after opening more passage text.</span>';
      answerHtml += '<br><br><b>Other possible evidence:</b><br>';
      picks.slice(1).forEach(function(p, idx) {
        answerHtml += '<br><b>' + (idx + 1) + '.</b> ' + esc(p.sentence);
        if (p.matched && p.matched.length) answerHtml += '<br><span class="sparx-reader-meta">matched: ' + esc(p.matched.join(', ')) + '</span>';
      });
      answerHtml += showFullExtract
        ? '<br><br>The full scanned extract is shown above with likely answer evidence highlighted. Read the highlighted parts in context before choosing.'
        : '<br><br>If the first one looks wrong, compare the others. Short or repeated question words can confuse the matcher, so use names, places, actions, or unusual words from the question.';
      answer.innerHTML = answerHtml;
    }
    function parseReaderChoices(text) {
      return text
        .split(/\n+/)
        .map(function(line) { return line.replace(/^\s*(?:[A-Da-d][\).:-]?|\d+[\).:-]?)\s*/, '').trim(); })
        .filter(function(line) { return line.length > 1; });
    }
    function compareReaderChoices() {
      var answer = document.getElementById('sparx-answer-text');
      var queryInput = document.getElementById('sparx-reader-query');
      var choicesInput = document.getElementById('sparx-reader-choices');
      if (!readerText) scanReaderPage();
      if (!readerText) return;
      var questionWords = (queryInput && queryInput.value || '').trim();
      var choices = parseReaderChoices((choicesInput && choicesInput.value) || '');
      if (!choices.length) {
        answer.textContent = 'Paste the answer choices first, one per line.';
        return;
      }
      var html = '<b>Choice evidence check</b><br>This keeps your choices in the order you pasted them. It does not rank or choose one.<br>';
      choices.forEach(function(choice, idx) {
        var evidence = scoreReaderSentences((questionWords + ' ' + choice).trim(), 3);
        html += '<br><b>Choice ' + (idx + 1) + ':</b> ' + esc(choice);
        if (!evidence.length) {
          html += '<br><span class="sparx-reader-meta">No strong matching evidence found. Check whether the choice uses synonyms or whether the relevant extract is visible.</span>';
          return;
        }
        evidence.forEach(function(item, evIdx) {
          html += '<br><span class="sparx-reader-meta">Evidence ' + (evIdx + 1) + ':</span> ' + esc(item.sentence);
          if (item.matched && item.matched.length) html += '<br><span class="sparx-reader-meta">matched: ' + esc(item.matched.join(', ')) + '</span>';
        });
        html += '<br><span class="sparx-reader-meta">Check: does this evidence actually prove the whole choice, or only share similar words?</span>';
      });
      answer.innerHTML = html;
    }
    function readerPrompt(text) {
      var platform = isMusicFirst ? 'MusicFirst' : 'Sparx Reader';
      return 'You are a reading/music tutor helping a student understand a ' + platform + ' page. Do not give final answers to quiz or homework questions, do not tell the student which option to choose, and do not write a response they can paste as an answer. Instead, give a more detailed study guide with:\n\n1. A clear plain-English summary.\n2. The main events or ideas in order.\n3. Key details the student should reread, with short evidence quotes where useful.\n4. Important vocabulary with simple definitions.\n5. For any visible questions, give hints, evidence locations, and thinking steps only.\n6. Common trap answers or misunderstandings to watch for, without revealing the correct answer.\n7. Two confidence-check questions the student can answer themselves.\n\nVisible page text:\n' + text.substring(0, 10000);
    }
    function readerSummaryPrompt(text) {
      var platform = isMusicFirst ? 'MusicFirst' : 'Sparx Reader';
      return 'You are a reading/music tutor. Summarise this ' + platform + ' extract in detail, but do not answer any quiz or homework questions. Include:\n\n1. A one-sentence gist.\n2. A detailed paragraph-by-paragraph or event-by-event summary.\n3. The key characters, places, ideas, or musical concepts.\n4. Important evidence details worth remembering.\n5. Vocabulary and meanings.\n6. The mood/tone and why.\n7. Three things the student should reread before answering questions.\n\nVisible page text:\n' + text.substring(0, 12000);
    }
    function readerReasoningPrompt(text, question, choices, reasoning) {
      var platform = isMusicFirst ? 'MusicFirst' : 'Sparx Reader';
      return `You are a reading/music tutor checking a student's reasoning for a ${platform} question. Do not reveal the correct answer if the student is wrong. Do not rank choices. Do not say "choose A/B/C/D". Check only the student's stated reasoning against the extract. Give:

1. Verdict on reasoning only: strong, partly supported, weak, or missing evidence.
2. Evidence from the extract that supports their reasoning.
3. Evidence from the extract that might contradict or complicate it.
4. One specific question they should ask themselves before submitting.
5. A short improvement to their explanation, without changing it into a final answer.

Question words: ${question}

Choices, if provided:
${choices}

Student's chosen answer and why:
${reasoning}

Visible extract:
${text.substring(0, 12000)}`;
    }
    function runReaderAI(prompt, loadingMessage) {
      var t0 = Date.now();
      var answer = document.getElementById('sparx-answer-text');
      if (!readerText) scanReaderPage();
      if (!readerText) return;
      answer.className = 'sparx-answer-text loading';
      answer.textContent = loadingMessage;
      readerStats.aiCalls += 1;
      readerStats.lastAction = 'ai-call';
      chrome.storage.local.get(['sparxApiKey','sparxModel'], function(data) {
        if (!data.sparxApiKey) {
          answer.className = 'sparx-answer-text';
          answer.textContent = 'No API key saved. Click the extension icon, add a key, then come back to Reader.';
          return;
        }
        var model = data.sparxModel || 'groq';
        function done(text) {
          readerStats.lastMs = Date.now() - t0;
          answer.className = 'sparx-answer-text';
          try {
            renderMarkdown(text, answer);
          } catch(e) {
            answer.textContent = text;
          }
        }
        function fail(e) {
          readerStats.aiErrors += 1;
          readerStats.lastAction = 'ai-error';
          readerStats.lastMs = Date.now() - t0;
          answer.className = 'sparx-answer-text';
          answer.textContent = 'Could not create study help: ' + e.message;
        }
        if (model === 'anthropic' || model === 'claude-haiku') {
          var claudeModel = model === 'claude-haiku' ? 'claude-haiku-4-5-20251001' : 'claude-sonnet-4-6';
          fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: {'Content-Type':'application/json','x-api-key':data.sparxApiKey,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},
            body: JSON.stringify({model: claudeModel, max_tokens: 1400, messages: [{role:'user', content: prompt}]})
          }).then(function(r){ return r.json(); }).then(function(d) {
            if (d.type === 'error' || d.error) throw new Error((d.error && d.error.message) || 'Anthropic error');
            done((d.content && d.content[0] && d.content[0].text) || '');
          }).catch(fail);
        } else if (model === 'groq') {
          fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {'Content-Type':'application/json','Authorization':'Bearer ' + data.sparxApiKey},
            body: JSON.stringify({model: 'llama-3.3-70b-versatile', max_tokens: 1400, messages: [{role:'user', content: prompt}]})
          }).then(function(r){ return r.json(); }).then(function(d) {
            if (d.error) throw new Error(d.error.message);
            done((d.choices && d.choices[0] && d.choices[0].message && d.choices[0].message.content) || '');
          }).catch(fail);
        } else {
          fetch('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent?key=' + data.sparxApiKey, {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({contents: [{parts: [{text: prompt}]}]})
          }).then(function(r){ return r.json(); }).then(function(d) {
            if (d.error) throw new Error(d.error.message);
            done((d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts && d.candidates[0].content.parts[0] && d.candidates[0].content.parts[0].text) || '');
          }).catch(fail);
        }
      });
    }
    function getReaderStudyHelp() {
      if (!readerText) scanReaderPage();
      if (!readerText) return;
      runReaderAI(readerPrompt(readerText), 'Building question study help...');
    }
    function getReaderSummary() {
      if (!readerText) scanReaderPage();
      if (!readerText) return;
      runReaderAI(readerSummaryPrompt(readerText), 'Building detailed summary...');
    }
    function checkReaderReasoning() {
      if (!readerText) scanReaderPage();
      if (!readerText) return;
      var reasoning = (document.getElementById('sparx-reader-reasoning').value || '').trim();
      if (!reasoning) {
        document.getElementById('sparx-answer-text').textContent = 'Write your chosen answer and why first.';
        return;
      }
      var question = (document.getElementById('sparx-reader-query').value || '').trim();
      var choices = (document.getElementById('sparx-reader-choices').value || '').trim();
      runReaderAI(readerReasoningPrompt(readerText, question, choices, reasoning), 'Checking your reasoning...');
    }
    return;
  }

  var currentQuestion=''; var currentCode='?'; var currentImageB64=null; var currentGraphB64=null; var hasRealImage=false; var currentAnswer=''; var currentFullAnswer=''; var currentTranscript=''; var history=[]; var lastUrl=location.href;
  var sparxKeybind='Shift+S'; var autoFilling=false; var inputBoxCount=0; var isCardQuestion=false; var slotCount=0; var hasClickableCards=false; var cardChoices=[]; var selectOptions=[];
  var loadingText='Thinking...'; var errorText='Error'; var explainStyle='normal'; var lastErrorTime=0;

  chrome.storage.local.get(['sparxKeybind','sparxHistory','sparxLoadingText','sparxErrorText','sparxExplainStyle'], function(data) {
    if (data.sparxKeybind) sparxKeybind = data.sparxKeybind;
    if (data.sparxHistory) { history = data.sparxHistory; renderHist(); }
    if (data.sparxLoadingText) loadingText = data.sparxLoadingText;
    if (data.sparxErrorText) errorText = data.sparxErrorText;
    if (data.sparxExplainStyle) explainStyle = data.sparxExplainStyle;
  });

  function saveHistory() { chrome.storage.local.set({ sparxHistory: history }); }

  function renderMarkdown(text, el) {
    try {
      el.innerHTML = marked.parse(text);
      if (typeof renderMathInElement !== 'undefined') {
        renderMathInElement(el, {
          delimiters: [
            {left:'$$', right:'$$', display:true},
            {left:'$', right:'$', display:false},
            {left:'\\(', right:'\\)', display:false},
            {left:'\\[', right:'\\]', display:true}
          ],
          throwOnError: false
        });
      }
    } catch(e) { el.textContent = text; }
  }

  function stripLatex(s) {
    return s
      .replace(/\$\$([^$]*)\$\$/g, '$1')
      .replace(/\$([^$]*)\$/g, '$1')
      .replace(/\\frac\{([^}]*)\}\{([^}]*)\}/g, '$1/$2')
      .replace(/\\left|\\right|\\cdot|\\times/g, '')
      .replace(/\*\*/g, '')
      .replace(/\\/g, '')
      .replace(/[{}]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Parse multi-part answers like "a) 5", "b) 3" from AI response
  function parsePartAnswers(full) {
    var lines = full.trim().split('\n').filter(function(l){return l.trim();});
    var parts = [];
    for (var i=0; i<lines.length; i++) {
      var l = stripLatex(lines[i].trim());
      // Match "a) 5", "(a) 5", "a. 5", "a: 5" — but NOT math like "c = 5" or "x + 2"
      var m = l.match(/^\(?([a-z])\)?[\.\):\s]\s*(.+)$/i);
      // Skip if letter is a common math variable followed by = or operator (not a part label)
      if (m && /^[=≈<>²³√+\-*×÷^]/.test(m[2].trim())) { m = null; }
      if (m && m[2].trim().length > 0 && m[2].trim().length < 40) {
        parts.push({ label: m[1].toLowerCase(), answer: m[2].trim() });
      }
    }
    return parts;
  }

  // Save each part as a separate history entry
  function savePartAnswers(fullText) {
    var parts = parsePartAnswers(fullText);
    if (parts.length <= 1) return; // not multi-part, handled normally
    for (var p=0; p<parts.length; p++) {
      var partCode = currentCode + ' ' + parts[p].label + ')';
      var found = false;
      for (var i=0; i<history.length; i++) {
        if (history[i].code === partCode) { history[i].ans = parts[p].answer; found=true; break; }
      }
      if (!found) {
        history.unshift({code: partCode, ans: parts[p].answer, full: fullText, part: parts[p].label});
        if (history.length > 40) history.pop();
      }
    }
  }

  function extractShortAnswer(full) {
    var lines = full.trim().split('\n').filter(function(l){return l.trim();});

    if (inputBoxCount > 1) {
      // For multi-box: look for a pipe-separated line first
      for (var i=lines.length-1; i>=0; i--) {
        var l = stripLatex(lines[i].trim());
        if (l.indexOf('|') !== -1) return l;
      }
      // Standard form detection: "3.5 × 10^4" → "3.5 | 4"
      if (inputBoxCount === 2) {
        var sfClean = stripLatex(full).replace(/\s+/g,' ');
        var sfm = sfClean.match(/(-?\d+(?:\.\d+)?)\s*[×x\*]?\s*(?:times)?\s*10\s*\^?\s*\{?\s*(-?\d+)\s*\}?/i);
        if (sfm) return sfm[1] + ' | ' + sfm[2];
      }
      // No pipe line found — collect numeric answers from lines like "a) 5", "b) 3"
      var vals = [];
      for (var i=0; i<lines.length; i++) {
        var l = stripLatex(lines[i].trim());
        var m = l.match(/^[a-z]\)\s*(.+)$/i);
        if (m) {
          var v = m[1].trim();
          if (v.length > 0 && v.length < 30) vals.push(v);
        }
      }
      if (vals.length >= inputBoxCount) return vals.join(' | ');
      // Last resort: extract all numbers
      var nums = full.match(/-?\d+(\.\d+)?/g);
      if (nums && nums.length >= inputBoxCount) return nums.slice(-inputBoxCount).join(' | ');
    }

    // Check for multi-part answers — return FIRST part, not last
    var parts = parsePartAnswers(full);
    if (parts.length > 1) {
      return parts[0].answer;
    }

    // Single answer: prefer the last line that looks like a clean answer (short, mostly numeric)
    // First pass: look for a very short answer-like line from the end
    for (var i=lines.length-1; i>=0; i--) {
      var l = stripLatex(lines[i].trim());
      if (l.length > 0 && l.length < 20 && /\d/.test(l)) return l;
    }
    // Second pass: any short line from the end
    for (var i=lines.length-1; i>=0; i--) {
      var l = stripLatex(lines[i].trim());
      if (l.length > 0 && l.length < 40) return l;
    }
    return stripLatex(lines[lines.length-1].trim()).substring(0,40);
  }

  function getSavedAnswer(code) {
    for (var i=0; i<history.length; i++) {
      if (history[i].code === code) return history[i].ans;
    }
    return null;
  }

  // Extract clean question text from the wrapper
  function extractCleanQuestion(wrapper) {
    // Read directly from live DOM
    var text = wrapper.innerText.trim().replace(/\s+/g, ' ');
    // Strip drag-and-drop accessibility sentences (match up to next period)
    text = text.replace(/To pick up a draggable item[^.]*\./gi, '');
    text = text.replace(/While dragging[^.]*\./gi, '');
    text = text.replace(/Press space (?:bar )?to (?:pick up|drop|move)[^.]*\./gi, '');
    text = text.replace(/\bSubmit\b/g, '').replace(/\bWatch video\b/gi, '');
    text = text.replace(/\s+/g, ' ').trim();
    // Grab math from KaTeX annotations — innerText often misses these
    wrapper.querySelectorAll('.katex-mathml annotation').forEach(function(ann) {
      var m = stripLatex(ann.textContent).trim();
      if (m && text.indexOf(m) === -1) text += ' ' + m;
    });
    // Grab alt text from images (equations can be images)
    wrapper.querySelectorAll('img').forEach(function(img) {
      if (img.closest('#sparx-solver-box')) return;
      var alt = (img.alt || img.getAttribute('aria-label') || '').trim();
      if (alt && text.indexOf(alt) === -1) text += ' ' + alt;
    });
    return text.substring(0, 600);
  }

  // Readable version of option text — for showing to the AI in prompts
  function getOptionTextReadable(el) {
    // 1. KaTeX annotation → light cleanup (keep structure readable)
    var ann = el.querySelector('.katex-mathml annotation');
    if (ann && ann.textContent.trim()) {
      return stripLatex(ann.textContent).trim();
    }
    // 2. aria-label / data attributes
    var aria = el.getAttribute('aria-label') || el.getAttribute('data-value') || '';
    if (aria.trim()) return aria.trim();
    // 3. Visible text (remove hidden MathML duplicates)
    var clone = el.cloneNode(true);
    clone.querySelectorAll('.katex-mathml').forEach(function(m) { m.remove(); });
    var vis = clone.textContent.trim();
    if (vis) return vis;
    return el.innerText.trim().split('\n')[0].trim();
  }

  // Stripped version — for fuzzy matching (lowercase, no spaces)
  function getOptionText(el) {
    return getOptionTextReadable(el).normalize('NFKC').toLowerCase().replace(/\s+/g,'');
  }

  function sparxClick(el) {
    var rect = el.getBoundingClientRect();
    var cx = rect.left + rect.width / 2;
    var cy = rect.top + rect.height / 2;
    var shared = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
    // PointerEvents first (React 17+ listens on these)
    el.dispatchEvent(new PointerEvent('pointerdown', shared));
    el.dispatchEvent(new PointerEvent('pointerup', shared));
    // Then classic MouseEvents
    el.dispatchEvent(new MouseEvent('mousedown', shared));
    el.dispatchEvent(new MouseEvent('mouseup', shared));
    el.dispatchEvent(new MouseEvent('click', shared));
  }

  function typeIntoInput(input, value, callback) {
    sparxClick(input);
    input.focus();
    var chars = value.toString().split('');
    var delay = 0;
    chars.forEach(function(char, i) {
      setTimeout(function() {
        var keyCode = char === '-' ? 189 : char === '.' ? 190 : char.charCodeAt(0);
        ['keydown','keypress','keyup'].forEach(function(ev) {
          input.dispatchEvent(new KeyboardEvent(ev, {
            key: char,
            code: 'Digit'+char,
            keyCode: keyCode,
            which: keyCode,
            bubbles: true,
            cancelable: true
          }));
        });
        var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        nativeSetter.call(input, value.toString().substring(0, i+1));
        input.dispatchEvent(new Event('input', { bubbles: true }));
      }, delay);
      delay += 35;
    });
    setTimeout(function() { if (callback) callback(); }, delay + 40);
  }

  // Split answer into parts for multi-box questions
  // First tries pipe-separated format (from AI prompt), then falls back to number extraction
  function splitAnswerParts(answer) {
    var clean = stripLatex(answer);
    // Try pipe-separated format first (e.g. "5 | 3 | 7" or "3 | 5" for fraction)
    if (clean.indexOf('|') !== -1) {
      var pipeParts = clean.split('|').map(function(p){ return p.trim(); }).filter(function(p){ return p.length > 0; });
      if (pipeParts.length > 1) return pipeParts;
    }
    // Try comma-separated format (e.g. "5, 3, 7")
    if (clean.indexOf(',') !== -1) {
      var commaParts = clean.split(',').map(function(p){ return p.trim(); }).filter(function(p){ return p.length > 0; });
      if (commaParts.length > 1) return commaParts;
    }
    if (inputBoxCount === 2) {
      // Standard form detection: "2 × 10^5", "2 x 10^5", "2 10^5" (× stripped), "2 times 10^5"
      var sfMatch = clean.match(/^(-?\d+(?:\.\d+)?)\s*[×x\*]?\s*(?:times)?\s*10\s*\^?\s*\{?\s*(-?\d+)\s*\}?$/i);
      if (sfMatch) return [sfMatch[1], sfMatch[2]];
      // Fraction detection: a/b or a÷b → [numerator, denominator]
      var fracMatch = clean.match(/^(-?\d+(?:\.\d+)?)\s*[\/÷]\s*(-?\d+(?:\.\d+)?)$/);
      if (fracMatch) return [fracMatch[1], fracMatch[2]];
    }
    // Fallback: extract all numbers (including negatives/decimals)
    var parts = [];
    var matches = clean.match(/-?\d+(\.\d+)?/g);
    if (matches) parts = matches;
    return parts;
  }

  function startAutoFill() {
    if (isTimesTablePage()) return;
    if (autoFilling) { stopAutoFill(); return; }
    autoFilling = true;
    lastManualInput = ''; // Clear so stale manual values don't interfere
    var btn = document.getElementById('sparx-autofill-btn');
    btn.textContent = 'Stop';
    btn.style.background = '#c0392b';
    runAutoFillCycle();
  }

  function runAutoFillCycle() {
    if (!autoFilling) return;

    // If on results/feedback page (blue continue button visible), click through it
    var blueBtn = document.querySelector('[class*=_ButtonBlue_]');
    if (blueBtn) {
      sparxClick(blueBtn);
      setTimeout(function() { if (autoFilling) runAutoFillCycle(); }, 900);
      return;
    }

    // If on summary/completion page, try to click through it
    if (isSummaryPage()) {
      var doneBtn = document.querySelector('[class*=_ButtonPrimary_]') ||
                    document.querySelector('button[class*=_Button_]');
      if (doneBtn) sparxClick(doneBtn);
      setTimeout(function() { if (autoFilling) runAutoFillCycle(); }, 900);
      return;
    }

    // 1. Read everything fresh from the DOM
    var codeEl = document.querySelector('[class*=_Selected_]');
    currentCode = codeEl ? codeEl.innerText.trim() : '?';
    var exact = document.querySelector('[class*=QuestionWrapper]');
    if (exact && !exact.closest('#sparx-solver-box')) {
      currentQuestion = extractCleanQuestion(exact);
      lastQuestionText = currentQuestion.substring(0, 200);
      lastDetectedCode = currentCode;
      hasRealImage = hasQuestionMedia(exact);
    } else {
      setTimeout(function() { if (autoFilling) runAutoFillCycle(); }, 500);
      return;
    }

    // Clear old answer/image data
    currentAnswer = '';
    currentFullAnswer = '';
    currentImageB64 = null;
    currentGraphB64 = null;
    currentTranscript = '';
    inputBoxCount = 0;
    cardChoices = [];

    // Update panel display (full text, collapsible)
    var d = document.getElementById('sparx-q-display');
    if (d) {
      var qText = currentQuestion + (hasRealImage ? ' [image]' : '');
      d.textContent = qText;
      d.classList.add('has-text');
      d.classList.remove('expanded');
      if (qText.length < 100) d.classList.add('short-text');
      else d.classList.remove('short-text');
    }

    // 2. Click "Answer" to reveal input boxes
    var answerBtn = Array.from(document.querySelectorAll('[class*=_ButtonPrimary_]')).find(function(b) {
      return b.innerText.trim() === 'Answer';
    });
    function detectQuestionType() {
      inputBoxCount = getNumericInputs().length;
      var slotEls = Array.from(document.querySelectorAll('[class*=_InlineSlot],[class*=_CardSlot]')).filter(function(el) {
        if (el.closest('#sparx-solver-box')) return false;
        var cls = typeof el.className === 'string' ? el.className : '';
        if (cls.indexOf('Wrapper') !== -1 || cls.indexOf('Outline') !== -1 || cls.indexOf('Focus') !== -1) return false;
        return true;
      });
      slotCount = slotEls.length;
      hasClickableCards = !!document.querySelector('[class*=_CardContentClickable]:not(#sparx-solver-box [class*=_CardContentClickable])');
      isCardQuestion = !inputBoxCount && !!(
        hasClickableCards ||
        document.querySelector('[class*=_CardContent]') ||
        slotEls.length ||
        document.querySelector('[class*=_Option_]')
      );
    }
    function gatherSelectOptions() {
      selectOptions = [];
      document.querySelectorAll('[class*=_AnswerContent] select, [class*=_Answer_] select, [class*=_QuestionWrapper] select').forEach(function(sel) {
        if (sel.closest('#sparx-solver-box')) return;
        var opts = [];
        for (var i = 0; i < sel.options.length; i++) {
          var t = sel.options[i].textContent.trim();
          if (t && t !== '' && t !== '--') opts.push(t);
        }
        if (opts.length) selectOptions.push(opts);
      });
    }
    function gatherCardChoices() {
      cardChoices = [];
      if (!hasClickableCards) return;
      var els = Array.from(document.querySelectorAll('[class*=_CardContentClickable]')).filter(function(el) {
        return !el.closest('#sparx-solver-box');
      });
      els.forEach(function(el, i) {
        cardChoices.push({ el: el, text: getOptionText(el), readable: getOptionTextReadable(el), index: i });
      });
    }

    if (answerBtn) {
      sparxClick(answerBtn);
      setTimeout(function() {
        if (!autoFilling) return;
        detectQuestionType();
        gatherCardChoices();
        gatherSelectOptions();
        captureAndSolve(exact);
      }, 450);
    } else {
      detectQuestionType();
      gatherCardChoices();
      gatherSelectOptions();
      captureAndSolve(exact);
    }
  }

  // Find a real content image inside the question area (not tiny icons)
  function findQuestionImage(container) {
    // Priority 1: Sparx's own _Image_ class
    var img = container.querySelector('img[class*=_Image_]');
    if (img) return img;
    // Priority 2: any <img> that is large enough to be a real content image (not a tiny icon)
    var allImgs = container.querySelectorAll('img');
    for (var i = 0; i < allImgs.length; i++) {
      var el = allImgs[i];
      if (el.closest('#sparx-solver-box')) continue;
      // Check natural size or rendered size — skip tiny icons (< 40px either dimension)
      var w = el.naturalWidth || el.width || el.offsetWidth || 0;
      var h = el.naturalHeight || el.height || el.offsetHeight || 0;
      if (w > 40 && h > 40) return el;
      // Also accept if src looks like a real image (not a data URI icon)
      if (el.src && el.src.indexOf('data:image/svg') === -1 && (w > 20 || h > 20)) return el;
    }
    return null;
  }

  function hasQuestionMedia(container) {
    if (findQuestionImage(container)) return true;
    // Check for canvas or video (not tiny icon SVGs)
    if (container.querySelector('canvas, video')) return true;
    // Only count SVGs that are large enough to be a real graph (not icons)
    var svgs = container.querySelectorAll('svg');
    for (var i = 0; i < svgs.length; i++) {
      var w = svgs[i].clientWidth || parseInt(svgs[i].getAttribute('width')) || 0;
      var h = svgs[i].clientHeight || parseInt(svgs[i].getAttribute('height')) || 0;
      if (w > 80 && h > 80) return true;
    }
    return false;
  }

  function trimCanvas(canvas) {
    var ctx = canvas.getContext('2d');
    var w = canvas.width, h = canvas.height;
    var data = ctx.getImageData(0, 0, w, h).data;
    var top = h, left = w, right = 0, bottom = 0;
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var i = (y * w + x) * 4;
        // Check if pixel is not white (allow near-white threshold)
        if (data[i] < 245 || data[i+1] < 245 || data[i+2] < 245) {
          if (y < top) top = y;
          if (y > bottom) bottom = y;
          if (x < left) left = x;
          if (x > right) right = x;
        }
      }
    }
    if (right <= left || bottom <= top) return canvas; // all white, return as-is
    // Add small padding
    var pad = 10;
    top = Math.max(0, top - pad);
    left = Math.max(0, left - pad);
    right = Math.min(w - 1, right + pad);
    bottom = Math.min(h - 1, bottom + pad);
    var trimmed = document.createElement('canvas');
    trimmed.width = right - left + 1;
    trimmed.height = bottom - top + 1;
    trimmed.getContext('2d').drawImage(canvas, left, top, trimmed.width, trimmed.height, 0, 0, trimmed.width, trimmed.height);
    return trimmed;
  }

  function captureAndSolve(exact) {
    if (!autoFilling) return;

    function doSolveAutofill() {
      solveForAutofill(function(answer) {
        if (!autoFilling) return;
        currentAnswer = answer;
        tryFill();
      });
    }

    if (hasRealImage) {
      // Fetch the actual image directly first (more reliable than html2canvas)
      var graphImg = findQuestionImage(exact);
      if (graphImg && graphImg.src) {
        fetchImageAsB64(graphImg.src, function(b64) {
          if (!autoFilling) return;
          if (b64) { currentImageB64 = b64; currentGraphB64 = b64; }
          fetchTranscript(function(transcript) { currentTranscript = transcript; });
          doSolveAutofill();
        });
      } else {
        // No direct image found, try html2canvas as fallback
        html2canvas(exact, {backgroundColor:'#ffffff', scale:2, useCORS:true, logging:false})
        .then(function(canvas) {
          if (!autoFilling) return;
          var trimmed = trimCanvas(canvas);
          currentImageB64 = trimmed.toDataURL('image/png').split(',')[1];
          doSolveAutofill();
        })
        .catch(function() {
          if (!autoFilling) return;
          doSolveAutofill();
        });
      }
    } else {
      // Always capture a lightweight screenshot so AI can see shapes, diagrams, sequences etc.
      html2canvas(exact, {backgroundColor:'#ffffff', scale:1, useCORS:true, logging:false})
      .then(function(canvas) {
        if (!autoFilling) return;
        var trimmed = trimCanvas(canvas);
        currentImageB64 = trimmed.toDataURL('image/png').split(',')[1];
        doSolveAutofill();
      })
      .catch(function() {
        if (!autoFilling) return;
        currentImageB64 = null;
        doSolveAutofill();
      });
    }
  }

  function stopAutoFill() {
    autoFilling = false;
    lastManualInput = ''; // Clear so auto-fill answers aren't saved as manual later
    var btn = document.getElementById('sparx-autofill-btn');
    if (btn) { btn.textContent = 'Auto-fill'; btn.style.background = ''; btn.disabled = false; }
  }

  // Normalize a math string for fuzzy comparison: strip parens/braces, sort characters
  function mathNorm(s) {
    return s.replace(/[(){}\[\]]/g,'').replace(/\s+/g,'');
  }
  // Extract just the "math characters" (letters, digits, operators) sorted for unordered comparison
  function mathSorted(s) {
    return s.replace(/[(){}\[\]\s]/g,'').split('').sort().join('');
  }

  function matchCards(cards, ansClean) {
    var best=null; var bestScore=-1;
    var ansNums = ansClean.replace(/[^0-9.\-\/]/g,'');
    var ansNorm = mathNorm(ansClean);
    var ansSorted = mathSorted(ansClean);
    cards.forEach(function(card) {
      var t = getOptionText(card);
      var tNums = t.replace(/[^0-9.\-\/]/g,'');
      var tNorm = mathNorm(t);
      var tSorted = mathSorted(t);
      var score = 0;
      // Exact match
      if (t===ansClean) score=100;
      // Match ignoring parens/braces
      else if (tNorm.length>0 && tNorm===ansNorm) score=90;
      // Substring match
      else if (t.length>0 && (ansClean.indexOf(t)!==-1||t.indexOf(ansClean)!==-1)) score=50;
      // Substring match ignoring parens
      else if (tNorm.length>1 && (ansNorm.indexOf(tNorm)!==-1||tNorm.indexOf(ansNorm)!==-1)) score=45;
      // Same characters in any order (catches equivalent math rearrangements)
      else if (tSorted.length>1 && tSorted===ansSorted) score=35;
      // Numeric-only match
      else if (ansNums.length>0 && tNums.length>0 && ansNums===tNums) score=30;
      if (score>bestScore) { bestScore=score; best=card; }
    });
    return bestScore>0 ? best : null;
  }

  function getNumericInputs() {
    var containers = document.querySelectorAll('[class*=_TextFieldNumeric_]');
    var inputs = [];
    var seen = new Set();
    containers.forEach(function(c) {
      var inp = c.tagName === 'INPUT' ? c : c.querySelector('input');
      if (inp && !seen.has(inp)) { inputs.push(inp); seen.add(inp); }
    });
    // Look for fraction inputs (numerator/denominator boxes)
    document.querySelectorAll('[class*=_Fraction] input, [class*=_FractionInput] input, [class*=_Numerator] input, [class*=_Denominator] input').forEach(function(inp) {
      if (!inp.closest('#sparx-solver-box') && !seen.has(inp)) { inputs.push(inp); seen.add(inp); }
    });
    // Fallback: try broader selector if nothing found
    if (!inputs.length) {
      document.querySelectorAll('[class*=_TextField_]').forEach(function(c) {
        var inp = c.tagName === 'INPUT' ? c : c.querySelector('input');
        if (inp && !seen.has(inp)) { inputs.push(inp); seen.add(inp); }
      });
    }
    // Broadest fallback: any input in the answer area
    if (!inputs.length) {
      document.querySelectorAll('[class*=_AnswerContent] input, [class*=_Answer_] input').forEach(function(inp) {
        if (!inp.closest('#sparx-solver-box') && inp.type !== 'hidden' && !seen.has(inp)) { inputs.push(inp); seen.add(inp); }
      });
    }
    // Also find select dropdowns in the answer area (e.g. exponent picker for standard form)
    document.querySelectorAll('[class*=_AnswerContent] select, [class*=_Answer_] select, [class*=_QuestionWrapper] select').forEach(function(sel) {
      if (!sel.closest('#sparx-solver-box') && !seen.has(sel)) { inputs.push(sel); seen.add(sel); }
    });
    return inputs;
  }

  function fillInput(el, value, callback) {
    if (el.tagName === 'SELECT') {
      // For select dropdowns: find matching option and set it
      var opts = el.options;
      var val = value.toString().trim();
      for (var i = 0; i < opts.length; i++) {
        if (opts[i].value === val || opts[i].textContent.trim() === val) {
          el.selectedIndex = i;
          var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set;
          nativeSetter.call(el, opts[i].value);
          el.dispatchEvent(new Event('change', { bubbles: true }));
          el.dispatchEvent(new Event('input', { bubbles: true }));
          break;
        }
      }
      if (callback) setTimeout(callback, 100);
    } else {
      typeIntoInput(el, value, callback);
    }
  }

  // Tokenize an equation answer into individual symbols for slot filling
  // "m=q×r" → ["m","=","q","×","r"], "m=qr" → ["m","=","q","r"]
  function tokenizeAnswer(ans) {
    var tokens = [];
    var current = '';
    var ops = '=+-×÷*/()^';
    for (var i = 0; i < ans.length; i++) {
      var ch = ans[i];
      if (ch === ' ') {
        if (current) { tokens.push(current); current = ''; }
        continue;
      }
      if (ops.indexOf(ch) !== -1) {
        if (current) { tokens.push(current); current = ''; }
        tokens.push(ch);
      } else if ('0123456789.'.indexOf(ch) !== -1) {
        // Group consecutive digits
        if (current && '0123456789.'.indexOf(current[0]) === -1) {
          tokens.push(current); current = '';
        }
        current += ch;
      } else {
        // Letters: each letter is its own token (variables are single-char)
        if (current) { tokens.push(current); current = ''; }
        tokens.push(ch);
      }
    }
    if (current) tokens.push(current);
    return tokens;
  }

  // Activate a slot with focus + pointer + mouse events (React needs pointer events)
  function sparxActivateSlot(el) {
    el.focus();
    ['pointerdown','pointerup'].forEach(function(ev) {
      el.dispatchEvent(new PointerEvent(ev, { bubbles: true, cancelable: true, view: window, pointerId: 1 }));
    });
    ['mousedown','mouseup','click'].forEach(function(ev) {
      el.dispatchEvent(new MouseEvent(ev, { bubbles: true, cancelable: true, view: window }));
    });
  }

  // Find tile cards — searches BottomBar, answer area, and traverses DOM near slots
  function findTileCards(slots, slotIdx) {
    // Only exclude cards inside the actual answer slots we're trying to fill
    var slotEls = slots && slots.length ? slots : Array.from(document.querySelectorAll('[class*=_InlineSlot],[class*=_CardSlot],[class*=_Slot_]'));

    function isSlotElement(el) {
      if (el.closest('#sparx-solver-box')) return true;
      for (var s = 0; s < slotEls.length; s++) {
        if (el === slotEls[s] || slotEls[s].contains(el)) return true;
      }
      return false;
    }

    // Strategy 1: CardContentClickable / CardContent (exclude slots)
    var cards = Array.from(document.querySelectorAll('[class*=_CardContentClickable],[class*=_CardContent_]')).filter(function(el) {
      return !isSlotElement(el);
    });
    if (cards.length) return { cards: cards, strategy: 'CardContent' };

    // Strategy 2: Search inside BottomBar (Sparx shows tiles at bottom)
    var bottomBar = document.querySelector('[class*=_BottomBar]');
    if (bottomBar && !bottomBar.closest('#sparx-solver-box')) {
      // Find all small elements with short text inside BottomBar (exclude nav buttons)
      cards = Array.from(bottomBar.querySelectorAll('*')).filter(function(el) {
        if (el.closest('#sparx-solver-box')) return false;
        // Exclude navigation buttons (Back, Answer, Submit, etc.)
        if (el.tagName === 'BUTTON') return false;
        if (el.closest('button')) return false;
        var elCls = typeof el.className === 'string' ? el.className : '';
        if (elCls.indexOf('Button') !== -1) return false;
        var t = el.textContent.trim();
        if (!t || t.length > 10) return false;
        if (el.children.length > 3) return false;
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 && r.width < 150 && r.height < 150;
      });
      if (cards.length) return { cards: cards, strategy: 'BottomBar' };
    }

    // Strategy 3: Walk UP from slot to find sibling containers with tiles
    var walkEl = slots[slotIdx];
    for (var up = 0; up < 6 && walkEl && walkEl.parentElement; up++) {
      walkEl = walkEl.parentElement;
      if (walkEl === document.body) break;
      for (var ci = 0; ci < walkEl.children.length; ci++) {
        var sibling = walkEl.children[ci];
        if (sibling.querySelector('[class*=_InlineSlot],[class*=_CardSlot]')) continue;
        if (sibling.closest('#sparx-solver-box')) continue;
        var found = Array.from(sibling.querySelectorAll('*')).filter(function(el) {
          if (el.closest('#sparx-solver-box')) return false;
          var t = el.textContent.trim();
          if (!t || t.length > 10) return false;
          if (el.children.length > 3) return false;
          // Exclude navigation buttons (Back, Answer, Submit, etc.)
          var elCls = typeof el.className === 'string' ? el.className : '';
          if (elCls.indexOf('Button') !== -1) return false;
          if (el.tagName === 'BUTTON') return false;
          if (el.closest('button')) return false;
          if (el.closest('[class*=_BottomBar]')) return false;
          var r = el.getBoundingClientRect();
          return r.width > 10 && r.height > 10 && r.width < 150 && r.height < 150;
        });
        if (found.length >= 5) {
          return { cards: found, strategy: 'sibling-L' + up + '-C' + ci };
        }
      }
    }

    // Strategy 4: Broader CSS selectors
    var broader = [
      '[class*=_KeypadButton]', '[class*=_PickerItem]', '[class*=_DraggableItem]',
      '[class*=_SelectableCard]', '[class*=_Symbol_]', '[class*=_Token_]',
      '[class*=_Available]', '[class*=_Clickable_]'
    ];
    for (var b = 0; b < broader.length; b++) {
      cards = Array.from(document.querySelectorAll(broader[b])).filter(function(el) {
        return !isSlotElement(el);
      });
      if (cards.length) return { cards: cards, strategy: 'broader-' + broader[b] };
    }

    return null;
  }

  // Flag to prevent our synthetic keyboard events from triggering the solver keybind
  var isSyntheticKey = false;

  // Dispatch keyboard events for a single key to the active element only
  function dispatchKey(key, token) {
    // Build proper code for the key
    var code = 'Key' + key.toUpperCase();
    if ('0123456789'.indexOf(key) !== -1) code = 'Digit' + key;
    else if (key === '+') code = 'Equal';
    else if (key === '-') code = 'Minus';
    else if (key === '=') code = 'Equal';
    else if (key === '/') code = 'Slash';
    else if (key === '*') code = 'Digit8';
    else if (key === '(') code = 'Digit9';
    else if (key === ')') code = 'Digit0';
    else if (key === '.') code = 'Period';
    else if (key === '^') code = 'Digit6';

    var kc = key.charCodeAt(0);
    var opts = { key: key, code: code, keyCode: kc, which: kc, bubbles: true, cancelable: true, composed: true };

    isSyntheticKey = true;

    // Dispatch ONLY to the active element (events bubble up to document naturally)
    var target = document.activeElement && document.activeElement !== document.body
      ? document.activeElement : document.body;

    target.dispatchEvent(new KeyboardEvent('keydown', opts));
    target.dispatchEvent(new KeyboardEvent('keypress', opts));
    target.dispatchEvent(new KeyboardEvent('keyup', opts));

    // Also try InputEvent
    try {
      target.dispatchEvent(new InputEvent('beforeinput', {
        data: token, inputType: 'insertText',
        bubbles: true, cancelable: true, composed: true
      }));
      target.dispatchEvent(new InputEvent('input', {
        data: token, inputType: 'insertText',
        bubbles: true, cancelable: true, composed: true
      }));
    } catch(e) {}

    isSyntheticKey = false;
  }

  // Type a token character into an active slot via keyboard events
  function typeTokenIntoSlot(slot, token, callback) {
    // Map special tokens to keyboard keys
    var key = token;
    if (token === '×') key = '*';
    if (token === '÷') key = '/';
    if (token === '−') key = '-';

    // Record state before typing
    var allSlots = Array.from(document.querySelectorAll('[class*=_InlineSlot],[class*=_CardSlot]')).filter(function(el) {
      return !el.closest('#sparx-solver-box');
    });
    var beforeTexts = allSlots.map(function(s) { return s.textContent.trim(); });

    // Dispatch keyboard events
    dispatchKey(key, token);

    // Check after delay if ANY slot content changed
    setTimeout(function() {
      var afterTexts = allSlots.map(function(s) { return s.textContent.trim(); });
      var anyChanged = false;
      for (var i = 0; i < allSlots.length; i++) {
        if (afterTexts[i] !== beforeTexts[i] && afterTexts[i] !== '-') {
          anyChanged = true;
          break;
        }
      }
      var noLongerEmpty = !slot.querySelector('[class*=_CardContentEmpty]');
      callback(anyChanged || noLongerEmpty);
    }, 500);
  }

  // Type all tokens sequentially via keyboard, letting the app manage slot focus
  function typeAllTokens(slots, tokens, tokenIdx) {
    if (!autoFilling) return;
    if (tokenIdx >= tokens.length) {
      // All tokens typed — wait a moment then submit
      saveDiag({ result: 'ALL TOKENS TYPED', allTokens: tokens.join(','), totalTyped: tokens.length, slots: slots.length, strategy: 'keyboard-seq' });
      setTimeout(clickSubmit, 800);
      return;
    }

    var token = tokens[tokenIdx];
    typeTokenIntoSlot(slots[0], token, function(success) {
      if (tokenIdx === 0 && !success) {
        // First token failed — keyboard input doesn't work for this question type
        // Stop immediately to avoid dispatching many useless events
        saveDiag({
          result: 'KEYBOARD NOT SUPPORTED',
          token: token,
          allTokens: tokens.join(','),
          slots: slots.length,
          activeElement: document.activeElement ? document.activeElement.className.substring(0, 80) : 'none',
          activeSlotHTML: slots[0] ? slots[0].outerHTML.substring(0, 400) : 'none'
        });
        stopAutoFill();
        return;
      }

      saveDiag({
        result: success ? 'KEY TYPED' : 'KEY TYPED (unconfirmed)',
        tokenIdx: tokenIdx,
        token: token,
        tokensLeft: tokens.length - tokenIdx - 1,
        allTokens: tokens.join(','),
        strategy: 'keyboard-seq',
        activeElement: document.activeElement ? document.activeElement.className.substring(0, 80) : 'none'
      });
      setTimeout(function() {
        typeAllTokens(slots, tokens, tokenIdx + 1);
      }, 200);
    });
  }

  // Fill empty slots with complete values (pipe-separated from AI)
  // Each value is a full expression like "y" or "2q" that goes into one slot
  function fillSlotsWithValues(emptySlots, values, idx) {
    if (!autoFilling) return;
    if (idx >= values.length || idx >= emptySlots.length) {
      setTimeout(clickSubmit, 600);
      return;
    }

    // Click the slot to activate it (sparxClick includes coordinates for React)
    sparxClick(emptySlots[idx]);
    emptySlots[idx].focus();

    setTimeout(function() {
      if (!autoFilling) return;

      var value = values[idx];
      // Search for a tile card matching this value
      var result = findTileCards(emptySlots, idx);
      var optTiles = findOptionTiles();
      var allChoices = (result ? result.cards : []).concat(optTiles);

      // Try to match the value against available tiles/options
      var matched = null;
      var choiceTexts = [];
      allChoices.forEach(function(card) {
        var t = getOptionText(card);
        choiceTexts.push(t);
        if (t === value) matched = card;
        else if (value.indexOf(t) !== -1 || t.indexOf(value) !== -1) {
          if (!matched) matched = card;
        }
      });

      if (matched) {
        sparxClick(matched);
        saveDiag({ result: 'SLOT VALUE FILL', slotIdx: idx, value: value, matched: getOptionText(matched), valuesLeft: values.length - idx - 1, choiceTexts: choiceTexts });
        setTimeout(function() {
          fillSlotsWithValues(emptySlots, values, idx + 1);
        }, 500);
      } else {
        // No tile match — try keyboard typing for this value
        var tokens = tokenizeAnswer(value);
        saveDiag({ result: 'SLOT VALUE → TYPING', slotIdx: idx, value: value, tokens: tokens, choiceTexts: choiceTexts });
        typeAllTokens(emptySlots, tokens, 0);
      }
    }, 900);
  }

  // Fill equation builder slots one at a time
  function fillSlotsSequentially(origSlots, tokens, slotIdx, tokenIdx) {
    if (!autoFilling) return;
    if (tokenIdx >= tokens.length) {
      setTimeout(clickSubmit, 600);
      return;
    }

    // Re-query empty slots in case DOM changed after previous card placement
    var freshSlots = Array.from(document.querySelectorAll('[class*=_InlineSlot],[class*=_CardSlot],[class*=_Slot_]')).filter(function(s) {
      if (s.closest('#sparx-solver-box')) return false;
      return !!s.querySelector('[class*=_CardContentEmpty]');
    });

    // Use fresh empty slot if available, otherwise fall back to original reference
    var targetSlot = freshSlots[0] || origSlots[slotIdx];
    if (!targetSlot || slotIdx >= origSlots.length) {
      setTimeout(clickSubmit, 600);
      return;
    }

    // Click the slot to activate it (sparxClick includes coordinates for React)
    sparxClick(targetSlot);
    targetSlot.focus();

    setTimeout(function() {
      if (!autoFilling) return;

      // Use all current empty slots for the isSlotElement filter
      var allSlotEls = Array.from(document.querySelectorAll('[class*=_InlineSlot],[class*=_CardSlot],[class*=_Slot_]'));
      var result = findTileCards(allSlotEls, 0);
      var token = tokens[tokenIdx];

      if (result && result.cards.length) {
        // Found tile cards — try to match and click
        var cards = result.cards;
        var matched = null;
        var cardTextsDebug = [];

        cards.forEach(function(card) {
          var t = getOptionText(card);
          cardTextsDebug.push(t);
          if (matched) return; // already found
          if (t === token) matched = card;
          else if (mathNorm(t) === mathNorm(token)) matched = card;
          else if (token === '/' && (t === '÷' || t === 'divide')) matched = card;
          else if (token === '÷' && (t === '/' || t === 'divide')) matched = card;
          else if (token === '*' && (t === '×' || t === 'multiply')) matched = card;
          else if (token === '×' && (t === '*' || t === 'multiply')) matched = card;
          // Fuzzy: strip spaces/parens and compare
          else if (t.length > 1 && token.length > 1 && t.replace(/\s/g,'') === token.replace(/\s/g,'')) matched = card;
          // Sorted character comparison for reordered math expressions
          else if (t.length > 1 && token.length > 1 && mathSorted(t) === mathSorted(token)) matched = card;
        });

        if (matched) {
          sparxClick(matched);
          saveDiag({ result: 'SLOT FILL', slotIdx: slotIdx, token: token, matched: getOptionText(matched), tokensLeft: tokens.length - tokenIdx - 1, allTokens: tokens.join(','), cardTexts: cardTextsDebug, strategy: result.strategy });
          setTimeout(function() {
            fillSlotsSequentially(origSlots, tokens, slotIdx + 1, tokenIdx + 1);
          }, 500);
        } else {
          // No matching tile card — fall back to keyboard typing for ALL remaining tokens
          saveDiag({ result: 'NO TILE MATCH → KEYBOARD', slotIdx: slotIdx, token: token, cardTexts: cardTextsDebug, allTokens: tokens.join(','), cards: cards.length, strategy: result.strategy });
          typeAllTokens(origSlots, tokens, tokenIdx);
        }
      } else {
        // No tile cards found at all — use keyboard typing for ALL remaining tokens
        saveDiag({ result: 'NO TILES → KEYBOARD', slotIdx: slotIdx, token: token, allTokens: tokens.join(','), strategy: 'no-tiles' });
        typeAllTokens(origSlots, tokens, tokenIdx);
      }
    }, 900);
  }

  // Extract info about all media inside the question area
  function extractMediaInfo() {
    var exact = document.querySelector('[class*=QuestionWrapper]');
    if (!exact) return null;
    var info = {};

    // SVGs (filter out tiny icons < 50px)
    var svgs = Array.from(exact.querySelectorAll('svg')).filter(function(s) {
      var w = s.clientWidth || parseInt(s.getAttribute('width')) || 0;
      var h = s.clientHeight || parseInt(s.getAttribute('height')) || 0;
      return w > 50 && h > 50;
    });
    if (svgs.length) {
      info.svgs = [];
      svgs.forEach(function(svg, si) {
        var svgData = { index: si, width: svg.clientWidth || svg.getAttribute('width'), height: svg.clientHeight || svg.getAttribute('height') };
        var texts = [];
        svg.querySelectorAll('text, tspan').forEach(function(t) {
          var txt = t.textContent.trim();
          if (txt && texts.indexOf(txt) === -1) texts.push(txt);
        });
        svgData.texts = texts;
        svgData.lines = svg.querySelectorAll('line').length;
        svgData.paths = svg.querySelectorAll('path').length;
        svgData.circles = svg.querySelectorAll('circle').length;
        svgData.rects = svg.querySelectorAll('rect').length;
        var points = [];
        svg.querySelectorAll('circle').forEach(function(c) {
          var cx = c.getAttribute('cx'), cy = c.getAttribute('cy');
          if (cx && cy) points.push('(' + cx + ',' + cy + ')');
        });
        if (points.length && points.length <= 20) svgData.points = points;
        svgData.viewBox = svg.getAttribute('viewBox') || '';
        info.svgs.push(svgData);
      });
    }

    // Canvas elements
    var canvases = exact.querySelectorAll('canvas');
    if (canvases.length) {
      info.canvases = [];
      canvases.forEach(function(c, i) {
        info.canvases.push({ index: i, width: c.width, height: c.height, className: (c.className || '').substring(0, 60) });
      });
    }

    // Images (filter out tiny icons)
    var imgs = Array.from(exact.querySelectorAll('img')).filter(function(img) {
      if (img.closest('#sparx-solver-box')) return false;
      var w = img.naturalWidth || img.width || img.offsetWidth || 0;
      var h = img.naturalHeight || img.height || img.offsetHeight || 0;
      return w > 50 && h > 50;
    });
    if (imgs.length) {
      info.images = [];
      imgs.forEach(function(img, i) {
        var src = img.src || '';
        // Truncate data URIs, show file URLs
        if (src.indexOf('data:') === 0) src = src.substring(0, 30) + '...';
        else if (src.length > 80) src = src.substring(0, 80) + '...';
        info.images.push({
          index: i,
          width: img.naturalWidth || img.width,
          height: img.naturalHeight || img.height,
          src: src,
          className: (img.className || '').substring(0, 60),
          alt: (img.alt || '').substring(0, 60)
        });
      });
    }

    return (info.svgs || info.canvases || info.images) ? info : null;
  }

  function saveDiag(obj) {
    obj.time = new Date().toLocaleTimeString();
    obj.isCardQuestion = isCardQuestion;
    obj.inputBoxCount = inputBoxCount;
    obj.question = currentQuestion.substring(0,120);
    // Attach media info if present
    var mediaInfo = extractMediaInfo();
    if (mediaInfo) obj.mediaInfo = mediaInfo;
    chrome.storage.local.set({ sparxDiagnostic: obj });
  }

  // Broadly search for clickable option tiles (the expression cards shown in card-selection questions)
  // These may not have _CardContentClickable but ARE visible tiles with math content
  function findOptionTiles() {
    var seen = new Set();
    var tiles = [];

    // Helper: is this element an empty slot or inside one?
    function isEmptySlotArea(el) {
      var slot = el.closest('[class*=_InlineSlot],[class*=_CardSlot]');
      if (slot && slot.querySelector('[class*=_CardContentEmpty]')) return true;
      if (typeof el.className === 'string' && el.className.indexOf('Empty') !== -1) return true;
      return false;
    }

    // Strategy A: _CardContent_ elements that aren't empty and aren't inside empty slots
    Array.from(document.querySelectorAll('[class*=_CardContent]')).forEach(function(el) {
      if (el.closest('#sparx-solver-box')) return;
      if (isEmptySlotArea(el)) return;
      if (el.textContent.trim().length < 1) return;
      if (!seen.has(el)) { seen.add(el); tiles.push(el); }
    });

    // Strategy B: _Tile_ elements that aren't empty slots
    Array.from(document.querySelectorAll('[class*=_Tile]')).forEach(function(el) {
      if (el.closest('#sparx-solver-box')) return;
      if (isEmptySlotArea(el)) return;
      if (el.querySelector('[class*=_CardContentEmpty]')) return;
      if (el.textContent.trim().length < 1) return;
      if (!seen.has(el)) { seen.add(el); tiles.push(el); }
    });

    // Strategy C: KaTeX math NOT inside a slot element (option tiles ARE inside QuestionWrapper)
    Array.from(document.querySelectorAll('.katex')).forEach(function(katex) {
      if (katex.closest('#sparx-solver-box')) return;
      // Skip KaTeX inside a slot element (that's the equation display, not an option)
      if (katex.closest('[class*=_InlineSlot],[class*=_CardSlot]')) return;
      // Walk up to find a tile-sized clickable parent
      var el = katex;
      for (var up = 0; up < 6 && el.parentElement; up++) {
        el = el.parentElement;
        if (el.closest('#sparx-solver-box')) break;
        if (el.tagName === 'BODY') break;
        // Skip if this IS a slot
        var elCls = typeof el.className === 'string' ? el.className : '';
        if (elCls.indexOf('InlineSlot') !== -1 || elCls.indexOf('CardSlot') !== -1) break;
        var r = el.getBoundingClientRect();
        if (r.width > 50 && r.width < 500 && r.height > 30 && r.height < 250) {
          if (!seen.has(el)) { seen.add(el); tiles.push(el); }
          break;
        }
      }
    });

    // Strategy D: Elements with tabindex/data-ref that look like clickable tiles
    Array.from(document.querySelectorAll('[tabindex][class*=_Tile],[tabindex][class*=_Card],[data-ref]:not([class*=_CardContentEmpty])'))
    .forEach(function(el) {
      if (el.closest('#sparx-solver-box')) return;
      if (isEmptySlotArea(el)) return;
      if (el.querySelector('[class*=_CardContentEmpty]')) return;
      if (el.textContent.trim().length < 1) return;
      var r = el.getBoundingClientRect();
      if (r.width < 40 || r.height < 25 || r.width > 500 || r.height > 250) return;
      if (!seen.has(el)) { seen.add(el); tiles.push(el); }
    });

    // Deduplicate: prefer outermost (remove children when parent is already in list)
    var deduped = tiles.filter(function(t) {
      for (var i = 0; i < tiles.length; i++) {
        if (tiles[i] !== t && tiles[i].contains(t)) return false;
      }
      return true;
    });

    return deduped;
  }

  // Fill any numeric inputs with remaining part answers (for multi-part questions)
  function fillRemainingInputs(callback) {
    var numInputs = getNumericInputs();
    if (!numInputs.length) { callback(); return; }

    // Try multiple strategies to find values for remaining inputs
    var values = [];

    // Strategy 1: pipe-separated answer parts (e.g. "Enlargement | 8")
    var short = currentAnswer || '';
    if (short.indexOf('|') !== -1) {
      var pipeParts = short.split('|').map(function(p) { return p.trim(); }).filter(function(p) { return p; });
      // Skip non-numeric parts (card labels like "Enlargement"), keep numeric ones
      pipeParts.forEach(function(p) {
        if (/\d/.test(p)) values.push(p);
      });
    }

    // Strategy 2: extract numbers from the short answer
    if (!values.length) {
      var nums = stripLatex(short).match(/-?\d+(\.\d+)?/g);
      if (nums) values = nums;
    }

    // Strategy 3: scan full AI response for last short numeric line
    if (!values.length && currentFullAnswer) {
      var lines = currentFullAnswer.trim().split('\n').filter(function(l){return l.trim();});
      for (var i=lines.length-1; i>=0; i--) {
        var l = stripLatex(lines[i].trim());
        if (l.match(/^[a-z]\)/)) continue;
        var numMatch = l.match(/-?\d+(\.\d+)?/);
        if (numMatch) { values.push(numMatch[0]); break; }
      }
    }

    if (!values.length) { callback(); return; }

    var idx = 0;
    function fillNext() {
      if (idx >= numInputs.length || idx >= values.length) { callback(); return; }
      var val = values[idx].replace(/[^0-9.\-\/]/g,'');
      if (!val) { idx++; fillNext(); return; }
      fillInput(numInputs[idx], val, function() { idx++; fillNext(); });
    }
    fillNext();
  }

  function tryFill() {
    if (!autoFilling) return;

    // Don't submit if answer is empty or looks like an API error
    if (!currentAnswer || currentAnswer.length < 1 || currentAnswer.indexOf('"type":"error"') !== -1) {
      lastErrorTime=Date.now();
      saveDiag({ result: 'NO ANSWER', ansClean: currentAnswer || '(empty)' });
      stopAutoFill();
      var at = document.getElementById('sparx-answer-text');
      if (at) at.textContent = errorText + ': No valid answer received';
      return;
    }

    var ansClean = stripLatex(currentAnswer).normalize('NFKC').toLowerCase().replace(/\s+/g,'');

    // ── CARD CHOICES: match AI answer against card options ──
    if (cardChoices.length > 0) {
      var choiceTexts = cardChoices.map(function(c) { return c.readable; });
      var liveCards = Array.from(document.querySelectorAll('[class*=_CardContentClickable]')).filter(function(el) {
        return !el.closest('#sparx-solver-box');
      });

      // Strategy 1: pure number → choice index
      var trimmed = currentAnswer.trim();
      if (/^\d+$/.test(trimmed)) {
        var choiceIdx = parseInt(trimmed, 10) - 1;
        if (choiceIdx >= 0 && choiceIdx < cardChoices.length) {
          var target = liveCards[choiceIdx] || cardChoices[choiceIdx].el;
          saveDiag({ result: 'CARD PICK', ansRaw: trimmed, picked: choiceIdx + 1, pickedText: cardChoices[choiceIdx].readable, choices: choiceTexts });
          sparxClick(target);
          setTimeout(function() { fillRemainingInputs(function() { setTimeout(clickSubmit, 300); }); }, 300);
          return;
        }
      }

      // Strategy 2: fuzzy match short answer against card texts
      var best = matchCards(liveCards, ansClean);

      // Strategy 3: fuzzy match using FULL AI response (catches correct answer in working)
      if (!best && currentFullAnswer) {
        var fullClean = stripLatex(currentFullAnswer).normalize('NFKC').toLowerCase().replace(/\s+/g,'');
        // Score each card by how well it matches anywhere in the full response
        var bestScore = -1;
        cardChoices.forEach(function(c, i) {
          var ct = c.text;
          var cr = c.readable.toLowerCase().replace(/\s+/g,'');
          if (ct.length > 1 && fullClean.indexOf(ct) !== -1) {
            // Count occurrences — the correct answer is usually mentioned more
            var count = fullClean.split(ct).length - 1;
            var score = count * 10 + ct.length;
            if (score > bestScore) { bestScore = score; best = liveCards[i] || c.el; }
          } else if (cr.length > 2 && fullClean.indexOf(cr) !== -1) {
            var count2 = fullClean.split(cr).length - 1;
            var score2 = count2 * 8 + cr.length;
            if (score2 > bestScore) { bestScore = score2; best = liveCards[i] || c.el; }
          }
        });
      }

      if (best) {
        saveDiag({ result: 'CARD MATCH', ansClean: ansClean, matched: getOptionText(best), choices: choiceTexts });
        sparxClick(best);
        setTimeout(function() { fillRemainingInputs(function() { setTimeout(clickSubmit, 300); }); }, 300);
        return;
      }

      // Card matching failed — but there may be number inputs or slots to fill too
      // Don't stop, fall through to try other filling methods
      saveDiag({ result: 'CARD NO MATCH → FALLTHROUGH', ansRaw: currentAnswer.substring(0, 80), ansClean: ansClean, choices: choiceTexts });
    }

    // ── Non-card questions: gather elements ──
    var cards = Array.from(document.querySelectorAll('[class*=_CardContentClickable]')).filter(function(el) {
      return !el.closest('#sparx-solver-box');
    });
    var slots = Array.from(document.querySelectorAll('[class*=_InlineSlot],[class*=_CardSlot]')).filter(function(el) {
      if (el.closest('#sparx-solver-box')) return false;
      var cls = typeof el.className === 'string' ? el.className : '';
      if (cls.indexOf('Wrapper') !== -1 || cls.indexOf('Outline') !== -1 || cls.indexOf('Focus') !== -1) return false;
      return true;
    });
    var options = Array.from(document.querySelectorAll('[class*=_Option_]')).filter(function(el) {
      return !el.closest('#sparx-solver-box');
    });
    var numInputs = getNumericInputs();
    var imageOptions = Array.from(document.querySelectorAll('[class*=_Option_]')).filter(function(o) { return o.querySelector('img'); });

    var cardTexts = []; cards.forEach(function(c){ cardTexts.push(getOptionText(c)); });
    var optTexts = []; options.forEach(function(o){ optTexts.push(getOptionText(o)); });
    var slotTexts = []; slots.forEach(function(s){ slotTexts.push(s.innerText.trim().normalize('NFKC').substring(0,30)); });

    // Base diagnostic data shared by all branches
    var baseDiag = {
      ansRaw: currentAnswer.substring(0, 80),
      ansClean: ansClean,
      cards: cards.length, cardTexts: cardTexts,
      slots: slots.length, slotTexts: slotTexts,
      options: options.length, optTexts: optTexts,
      numInputs: numInputs.length,
      imageOpts: imageOptions.length
    };

    // 1. Check for clickable cards (shouldn't reach here if cardChoices worked, but fallback)
    if (cards.length) {
      var best = matchCards(cards, ansClean);
      if (best) {
        baseDiag.result = 'CARD MATCH'; baseDiag.matched = getOptionText(best);
        saveDiag(baseDiag);
        sparxClick(best); setTimeout(function() { fillRemainingInputs(function() { setTimeout(clickSubmit, 300); }); }, 300); return;
      }
    }

    // 2. Slots — equation builder or single-slot card pick
    if (slots.length) {
      var emptySlots = slots.filter(function(s) { return !!s.querySelector('[class*=_CardContentEmpty]'); });
      var nonEmptySlots = slots.filter(function(s) { return !s.querySelector('[class*=_CardContentEmpty]'); });

      baseDiag.emptySlots = emptySlots.length;
      baseDiag.nonEmptySlots = nonEmptySlots.length;

      if (slots.length > 1 && emptySlots.length > 1) {
        // If answer has pipe separator (e.g. "11 | 3n"), split by pipe for slot values
        var rawAns = stripLatex(currentAnswer).trim();
        var tokens;
        if (rawAns.indexOf('|') !== -1) {
          tokens = rawAns.split('|').map(function(p) { return p.trim().toLowerCase().replace(/\s+/g,''); }).filter(function(p) { return p; });
        } else {
          tokens = tokenizeAnswer(ansClean);
        }
        baseDiag.result = 'MULTI-SLOT'; baseDiag.tokens = tokens; baseDiag.branch = tokens.length + ' tokens → ' + emptySlots.length + ' empty slots';
        saveDiag(baseDiag);
        fillSlotsSequentially(emptySlots, tokens, 0, 0);
        return;
      }

      // Single empty slot — click it, then try to match from revealed cards
      if (emptySlots.length >= 1) {
        baseDiag.result = 'SLOT CLICK';
        saveDiag(baseDiag);
        sparxClick(emptySlots[0]);
        setTimeout(function() {
          if (!autoFilling) return;
          var newCards = Array.from(document.querySelectorAll('[class*=_CardContentClickable]')).filter(function(el) {
            if (el.closest('#sparx-solver-box')) return false;
            // Exclude cards already placed inside slots
            for (var si = 0; si < slots.length; si++) {
              if (slots[si].contains(el)) return false;
            }
            return true;
          });
          // Try text matching first
          var best2 = matchCards(newCards, ansClean);
          if (best2) {
            saveDiag({ result: 'SLOT→CARD MATCH', ansClean: ansClean, matched: getOptionText(best2), choices: newCards.length });
            sparxClick(best2); setTimeout(function() { fillRemainingInputs(function() { setTimeout(clickSubmit, 300); }); }, 300);
            return;
          }
          // No text match — ask AI to pick from the revealed options
          if (newCards.length >= 2) {
            var revealedChoices = newCards.map(function(c, i) {
              return { el: c, readable: getOptionTextReadable(c), index: i };
            });
            var optList = revealedChoices.map(function(c, i) { return (i + 1) + ') ' + c.readable; }).join('\n');
            var pickPrompt = 'Question: ' + currentQuestion + '\n\nWhich of these options is the correct answer?\n' + optList + '\n\nReply with ONLY the number. Nothing else.';
            var ct = revealedChoices.map(function(c) { return c.readable; });
            saveDiag({ result: 'SLOT→AI PICK', ansClean: ansClean, choices: ct });
            chrome.storage.local.get(['sparxApiKey','sparxModel'], function(data) {
              if (!data.sparxApiKey || !autoFilling) { stopAutoFill(); return; }
              var model = data.sparxModel || 'groq';
              callAIPick(data.sparxApiKey, model, pickPrompt, function(resp) {
                if (!autoFilling) return;
                var numMatch = resp.match(/(\d+)/);
                var idx = numMatch ? parseInt(numMatch[1], 10) - 1 : -1;
                if (idx >= 0 && idx < newCards.length) {
                  saveDiag({ result: 'SLOT→AI PICKED', picked: idx + 1, pickedText: revealedChoices[idx].readable, choices: ct });
                  sparxClick(newCards[idx]); setTimeout(function() { fillRemainingInputs(function() { setTimeout(clickSubmit, 300); }); }, 300);
                } else {
                  saveDiag({ result: 'SLOT→AI PICK FAIL', aiResp: resp.substring(0, 40), choices: ct });
                  stopAutoFill();
                }
              }, function() { stopAutoFill(); });
            });
          } else {
            var ct = newCards.slice(0, 12).map(function(c) { return getOptionText(c); });
            saveDiag({ result: 'SLOT→NO MATCH', ansClean: ansClean, choices: newCards.length, choiceTexts: ct });
            stopAutoFill();
          }
        }, 450);
        return;
      }
    }

    // 3. Text/image multiple choice options
    if (options.length) {
      var textOpts = options.filter(function(o) { return !o.querySelector('img'); });
      if (textOpts.length) {
        var best = matchCards(textOpts, ansClean);
        if (best) {
          baseDiag.result = 'OPTION MATCH'; baseDiag.matched = getOptionText(best);
          saveDiag(baseDiag);
          sparxClick(best); setTimeout(clickSubmit, 400); return;
        }
      }
    }

    // 4. Number inputs
    if (numInputs.length) {
      var parts = splitAnswerParts(currentAnswer);
      baseDiag.result = 'NUM INPUT'; baseDiag.parts = parts; baseDiag.branch = 'typing into ' + numInputs.length + ' input(s)';
      saveDiag(baseDiag);
      if (numInputs.length === 1 || parts.length <= 1) {
        var val;
        if (parts.length) {
          val = parts[parts.length - 1];
        } else {
          // Extract just the last number, not all digits concatenated
          var nums = stripLatex(currentAnswer).match(/-?\d+(\.\d+)?/g);
          val = nums ? nums[nums.length - 1] : '';
        }
        fillInput(numInputs[0], val, function() {
          setTimeout(clickSubmit, 400);
        });
      } else {
        var idx = 0;
        function fillNext() {
          if (!autoFilling || idx >= numInputs.length) { setTimeout(clickSubmit, 400); return; }
          var val = parts[idx] !== undefined ? parts[idx] : '';
          if (val) {
            var inp = numInputs[idx];
            sparxClick(inp);
            inp.focus();
            if (inp.hasAttribute('readonly')) inp.removeAttribute('readonly');
            setTimeout(function() {
              fillInput(inp, val, function() {
                idx++;
                setTimeout(fillNext, 400);
              });
            }, 300);
          } else {
            idx++;
            setTimeout(fillNext, 200);
          }
        }
        fillNext();
      }
      return;
    }

    // 5. Image multiple choice
    if (imageOptions.length) {
      baseDiag.result = 'IMAGE OPTS'; baseDiag.branch = 'asking AI to pick from ' + imageOptions.length + ' image options';
      saveDiag(baseDiag);
      chrome.storage.local.get(['sparxApiKey'], function(data) {
        if (!data.sparxApiKey) { stopAutoFill(); return; }
        html2canvas(document.body, {backgroundColor:'#ffffff',scale:1.5,useCORS:true,logging:false})
        .then(function(canvas) {
          if (!autoFilling) return;
          var b64 = canvas.toDataURL('image/png').split(',')[1];
          fetch('https://api.anthropic.com/v1/messages',{
            method:'POST',
            headers:{'Content-Type':'application/json','x-api-key':data.sparxApiKey,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},
            body:JSON.stringify({model:'claude-sonnet-4-6',max_tokens:64,messages:[{role:'user',content:[
              {type:'image',source:{type:'base64',media_type:'image/png',data:b64}},
              {type:'text',text:'This is a Sparx Maths multiple choice question. The correct answer is: '+currentAnswer+'\n\nThere are '+imageOptions.length+' options. Reply with ONLY a number 1-'+imageOptions.length+' indicating which option (left to right, top to bottom) matches the correct answer.'}
            ]}]})
          })
          .then(function(r){return r.json();})
          .then(function(d) {
            if (!autoFilling) return;
            var idx = parseInt((d.content&&d.content[0]&&d.content[0].text||'').trim()) - 1;
            if (!isNaN(idx) && idx>=0 && idx<imageOptions.length) {
              sparxClick(imageOptions[idx]);
              setTimeout(clickSubmit, 400);
            } else { stopAutoFill(); }
          })
          .catch(function(){ stopAutoFill(); });
        });
      });
      return;
    }

    // Nothing found at all
    baseDiag.result = 'NOTHING FOUND';
    saveDiag(baseDiag);
    stopAutoFill();
  }

  function clickSubmit() {
    if (!autoFilling) return;
    var submitBtn = Array.from(document.querySelectorAll('[class*=_ButtonPrimary_]')).find(function(b) {
      return b.innerText.trim() !== 'Answer';
    });
    if (submitBtn) sparxClick(submitBtn);

    // Wait for result, then click continue and move to next question
    setTimeout(function() {
      if (!autoFilling) return;
      var continueBtn = document.querySelector('[class*=_ButtonBlue_]');
      if (continueBtn) sparxClick(continueBtn);

      // Wait for next question to load, then run next cycle
      waitForNextQuestion(lastQuestionText, 0);
    }, 900);
  }

  function waitForNextQuestion(oldText, attempts) {
    if (!autoFilling) return;
    if (attempts > 20) { stopAutoFill(); return; } // give up after ~10s
    if (isSummaryPage()) { stopAutoFill(); return; }

    // Check if a bookwork check appeared
    var chip = document.querySelector('[class*=_Bookwork_]');
    if (chip) {
      // Let the bookwork handler deal with it, then retry
      setTimeout(function() { waitForNextQuestion(oldText, attempts + 1); }, 250);
      return;
    }

    // If continue button is still visible, we're on the results/feedback page — not a new question
    var blueBtn = document.querySelector('[class*=_ButtonBlue_]');
    if (blueBtn) {
      sparxClick(blueBtn); // click continue again in case it didn't register
      setTimeout(function() { waitForNextQuestion(oldText, attempts + 1); }, 250);
      return;
    }

    // Check if question text has changed
    var exact = document.querySelector('[class*=QuestionWrapper]');
    var newText = (exact && !exact.closest('#sparx-solver-box')) ? exact.innerText.trim().substring(0,200) : '';
    if (newText && newText !== oldText) {
      // New question loaded — start next cycle.
      // Stagger Gemini-free-tier models to stay under per-minute rate limits.
      chrome.storage.local.get(['sparxModel'], function(data) {
        var m = data.sparxModel || 'groq';
        var delay = m.indexOf('gemini') === 0 ? 2500 : 250;
        setTimeout(runAutoFillCycle, delay);
      });
    } else {
      // Still waiting — retry
      setTimeout(function() { waitForNextQuestion(oldText, attempts + 1); }, 250);
    }
  }

  // Quick hardcoded answers for known patterns (skip AI call)
  function quickAnswer() {
    var q = currentQuestion.toLowerCase();
    // "I ___ written" → have
    if (/\bi\b.*\b(written|done|been|gone|seen|taken|eaten|given|chosen|spoken|broken|forgotten|driven|risen)\b/.test(q) && /select|choose|pick|option|click/i.test(q)) {
      return 'have';
    }
    return null;
  }

  function buildPrompt(isImage, answerOnly) {
    var transcriptNote = currentTranscript ? '\n\nHere is a transcript from the video explanation for this topic (first 400 words):\n'+currentTranscript : '';
    var multiBoxNote = '';
    if (inputBoxCount > 1) {
      multiBoxNote = '\n\nIMPORTANT: This question has ' + inputBoxCount + ' separate input boxes. Write ONLY the ' + inputBoxCount + ' values separated by | (pipe). For standard form (e.g. 2 × 10^5), give coefficient | power (e.g. 2 | 5). For fractions, give numerator | denominator. For example if there are 3 boxes: 5 | 12 | 7';
      if (selectOptions.length) {
        selectOptions.forEach(function(opts, i) {
          multiBoxNote += '\nDropdown ' + (i + 1) + ' options: ' + opts.join(', ');
        });
        multiBoxNote += '\nYour answer for each dropdown MUST be one of its available options exactly.';
      }
    }

    if (answerOnly) {
      // Full reasoning like the solve button, but answer on the last line
      var workNote = 'Think through this step by step. Show your full working, then on the very LAST line write ONLY the final answer with no extra words or punctuation.';
      var partNote = 'If the question has multiple parts (a, b, c...), answer EACH part on its own line like:\na) answer\nb) answer';
      var ansInst;
      if (inputBoxCount > 1) {
        ansInst = workNote + ' Always fully simplify each answer. Write fractions as a/b (e.g. 3/5, NOT 3÷5). If the question asks for a fraction with separate numerator and denominator boxes, give them as numerator | denominator (e.g. 3 | 5 for three fifths). On the very last line write ONLY the ' + inputBoxCount + ' answers separated by | (pipe). No words on that line.';
      } else if (cardChoices.length > 0) {
        var optList = cardChoices.map(function(c, i) { return (i + 1) + ') ' + c.readable; }).join('\n');
        ansInst = 'This is a multiple choice question. The available options are:\n' + optList + '\n\n' + workNote + ' On the very last line reply with ONLY the number of the correct option (e.g. 1, 2, 3...).';
      } else if (isCardQuestion && slotCount > 1) {
        ansInst = workNote + ' This is an equation builder with ' + slotCount + ' slots to fill. Always fully simplify. If the answer is a fraction, write it as numerator | denominator on the last line (e.g. 11 | 3n). Otherwise write the equation with explicit operators (use × for multiply). For example: m = q × r. On the very last line write ONLY the answer.';
      } else if (isCardQuestion) {
        ansInst = workNote + ' This is a multiple choice / click-to-select question. Write fractions as a/b (e.g. 11/3n, NOT 11÷3n). On the very last line write ONLY the exact text of the correct answer.';
      } else {
        ansInst = workNote + ' PLEASE always fully simplify fractions and equations. Collect like terms, reduce fractions, and solve for the variable completely (e.g. write y = 5, NOT y + 11 + 2y = 26; write 3/4, NOT 6/8). Always write fractions as a/b using a slash (NOT ÷). Keep fractions as fractions — do NOT convert to decimals unless asked. For y-intercept questions give ONLY the number (e.g. -9, NOT (0,-9)). For gradient/slope questions give ONLY the number (e.g. 8, NOT 8x). On the very last line write ONLY the final simplified answer. ' + partNote;
      }
      if (isImage) {
        return 'Solve this Sparx Maths question. Look at the screenshot image carefully — any equations, expressions, or statements may only be visible in the image.'+(currentGraphB64?' A separate high-res image is also attached.':'')+' Extracted text (may be incomplete): '+currentQuestion+transcriptNote+multiBoxNote+'\n\n'+ansInst;
      }
      return 'Solve this maths question. '+ansInst+transcriptNote+multiBoxNote+'\n\nQuestion: '+currentQuestion;
    }

    // Full mode: explanation + answer (used by Solve button)
    var styleNote = '';
    if (explainStyle === 'british') styleNote = ' Write your explanation in British slang (innit, bruv, mate, proper, etc.).';
    else if (explainStyle === 'pirate') styleNote = ' Write your explanation in pirate speak (arrr, ye, matey, plunder, etc.).';
    else if (explainStyle === 'shakespeare') styleNote = ' Write your explanation in Shakespearean English (thee, thou, hath, doth, forsooth, etc.).';
    var answerInstruction = inputBoxCount > 1
      ? 'On the very last line write ONLY the ' + inputBoxCount + ' answers separated by | (pipe character), with no extra words.'
      : 'If the question has multiple parts, answer each part on its own line using the format a) answer, b) answer, etc. Otherwise, on the very last line write only the final answer with no extra words or punctuation.';
    if (isImage) {
      return 'You are a maths tutor. This is a screenshot of a Sparx Maths question. Look at the screenshot carefully — any equations, expressions, or statements may only be visible in the image.'+(currentGraphB64?' A separate high-res image is also attached.':'')+' Extracted text (may be incomplete): '+currentQuestion+transcriptNote+multiBoxNote+'\n\nGive a brief explanation using markdown and LaTeX math (use $...$ for inline math).'+styleNote+' '+answerInstruction;
    }
    return 'You are a maths tutor. Give a brief explanation using markdown and LaTeX math (use $...$ for inline math).'+styleNote+' '+answerInstruction+transcriptNote+multiBoxNote+'\n\nQuestion: '+currentQuestion;
  }

  // Lightweight AI call with a custom prompt (for picking from revealed options)
  function callAIPick(key, model, prompt, onAnswer, onError) {
    if (model==='anthropic' || model==='claude-haiku') {
      var pickModel = model==='claude-haiku' ? 'claude-haiku-4-5-20251001' : 'claude-sonnet-4-6';
      fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'Content-Type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model:pickModel,max_tokens:32,messages:[{role:'user',content:prompt}]})})
      .then(function(r){return r.json();}).then(function(d){
        if(d.type==='error'||d.error){onError(new Error((d.error&&d.error.message)||'error'));return;}
        onAnswer((d.content&&d.content[0]&&d.content[0].text)||'');
      }).catch(onError);
    } else if (model==='groq') {
      fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},body:JSON.stringify({model:'llama-3.3-70b-versatile',max_tokens:32,messages:[{role:'user',content:prompt}]})})
      .then(function(r){return r.json();}).then(function(d){
        if(d.error){onError(new Error(d.error.message));return;}
        onAnswer((d.choices&&d.choices[0]&&d.choices[0].message&&d.choices[0].message.content)||'');
      }).catch(onError);
    } else {
      fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent?key='+key,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:[{parts:[{text:prompt}]}]})})
      .then(function(r){return r.json();}).then(function(d){
        if(d.error){onError(new Error(d.error.message));return;}
        onAnswer((d.candidates&&d.candidates[0]&&d.candidates[0].content&&d.candidates[0].content.parts&&d.candidates[0].content.parts[0]&&d.candidates[0].content.parts[0].text)||'');
      }).catch(onError);
    }
  }

  function callAI(key, model, onAnswer, onError, answerOnly) {
    var isImage = !!currentImageB64;
    var tokens = answerOnly ? 512 : 512;

    if (model==='anthropic' || model==='claude-haiku') {
      var claudeModel = model==='claude-haiku' ? 'claude-haiku-4-5-20251001' : 'claude-sonnet-4-6';
      var mc;
      if (isImage) {
        mc = [{type:'image',source:{type:'base64',media_type:'image/png',data:currentImageB64}}];
        if (currentGraphB64) mc.push({type:'image',source:{type:'base64',media_type:'image/png',data:currentGraphB64}});
        mc.push({type:'text',text:buildPrompt(true, answerOnly)});
      } else {
        mc = [{type:'text',text:buildPrompt(false, answerOnly)}];
      }
      fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'Content-Type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model:claudeModel,max_tokens:tokens,messages:[{role:'user',content:mc}]})})
      .then(function(r){return r.json();}).then(function(d){
        if(d.type==='error'||d.error){var msg=(d.error&&d.error.message)||'Unknown Anthropic error';onError(new Error(msg));return;}
        onAnswer((d.content&&d.content[0]&&d.content[0].text)||JSON.stringify(d),claudeModel);
      })
      .catch(onError);

    } else if (model==='groq') {
      var sysMsg = answerOnly
        ? 'Solve this maths question. PLEASE always fully simplify fractions and equations. Collect like terms, reduce fractions, and solve for the variable completely (e.g. write y = 5, NOT y + 11 + 2y = 26). Write fractions as a/b using a slash (e.g. 3/5, NOT 3÷5). Keep fractions as fractions, do NOT convert to decimals. For y-intercept give ONLY the number (e.g. -9, NOT (0,-9)). For gradient give ONLY the number (e.g. 8, NOT 8x). Reply with ONLY the final simplified answer. No explanation.'
        : 'You are a maths tutor. Give a brief explanation using markdown and LaTeX math (use $...$ for inline math). Always fully simplify your answers. On the very last line write only the final answer with no extra words or punctuation.';
      fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},body:JSON.stringify({model:'llama-3.3-70b-versatile',max_tokens:tokens,messages:[{role:'system',content:sysMsg},{role:'user',content:buildPrompt(false, answerOnly)}]})})
      .then(function(r){return r.json();}).then(function(d){
        if(d.error){onError(new Error(d.error.message)); return;}
        onAnswer((d.choices&&d.choices[0]&&d.choices[0].message&&d.choices[0].message.content)||'Could not get answer.','groq-llama');
      }).catch(onError);

    } else {
      var gp;
      if (isImage) {
        gp = [{inline_data:{mime_type:'image/png',data:currentImageB64}}];
        if (currentGraphB64) gp.push({inline_data:{mime_type:'image/png',data:currentGraphB64}});
        gp.push({text:buildPrompt(true, answerOnly)});
      } else {
        gp = [{text:buildPrompt(false, answerOnly)}];
      }
      var geminiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent?key='+key;
      var geminiBody = JSON.stringify({contents:[{parts:gp}]});
      function geminiRequest(retryCount) {
        fetch(geminiUrl,{method:'POST',headers:{'Content-Type':'application/json'},body:geminiBody})
        .then(function(r){return r.json();}).then(function(d){
          if(d.error) {
            if(d.error.code===429 && retryCount < 2) {
              // Auto-retry after delay (rate limit may be per-minute)
              setTimeout(function(){ geminiRequest(retryCount + 1); }, 3000);
              return;
            }
            var realMsg = d.error.message || 'Unknown error';
            var msg = realMsg;
            if(d.error.code===429) msg = 'Rate limit hit. Try Flash-Lite or Groq for higher limits. (Google: ' + realMsg + ')';
            else if(d.error.code===403) msg = 'Access denied. Key may be invalid or restricted — try a fresh key at aistudio.google.com/apikey. (Google: ' + realMsg + ')';
            else if(d.error.code===404) msg = 'Model not found — it may have been deprecated. Pick a different Gemini model in the popup. (Google: ' + realMsg + ')';
            else if(d.error.code===400) msg = 'Bad request: ' + realMsg;
            onError(new Error(msg)); return;
          }
          var text = d.candidates&&d.candidates[0]&&d.candidates[0].content&&d.candidates[0].content.parts&&d.candidates[0].content.parts[0]&&d.candidates[0].content.parts[0].text;
          if(!text && d.candidates&&d.candidates[0]&&d.candidates[0].finishReason==='SAFETY') { onError(new Error('Blocked by safety filter. Try rephrasing.')); return; }
          onAnswer(text||'Could not get answer.',model);
        }).catch(onError);
      }
      geminiRequest(0);
    }
  }

  function solveForAutofill(callback) {
    var at = document.getElementById('sparx-answer-text');
    var ab = document.getElementById('sparx-answer-box');
    ab.classList.add('visible');
    at.className='sparx-answer-text loading';
    at.textContent=loadingText;

    // Check for hardcoded quick answers first
    var quick = quickAnswer();
    if (quick) {
      at.className='sparx-answer-text';
      at.textContent = quick;
      currentFullAnswer = quick;
      callback(quick);
      return;
    }

    chrome.storage.local.get(['sparxApiKey','sparxModel'], function(data) {
      if (!data.sparxApiKey) { stopAutoFill(); return; }
      var model=data.sparxModel||'groq';
      if (currentImageB64&&model==='groq') { stopAutoFill(); at.textContent='Switch to Anthropic or Gemini for image questions.'; return; }

      callAI(data.sparxApiKey, model, function(a, modelUsed) {
        at.className='sparx-answer-text';
        renderMarkdown(a, at);
        currentFullAnswer = a;
        var short = extractShortAnswer(a);
        // Save main answer under current bookwork code (always move to front)
        for(var i=history.length-1;i>=0;i--){if(history[i].code===currentCode)history.splice(i,1);}
        history.unshift({code:currentCode,ans:short,full:a});
        if(history.length>40)history.pop();
        // Save each part as separate history entries (a), b), etc.)
        savePartAnswers(a);
        saveHistory(); renderHist(); saveDevInfo(modelUsed);
        callback(short);
      }, function(e){ at.textContent=errorText+': '+e.message; lastErrorTime=Date.now(); stopAutoFill(); }, true);
    });
  }

  // Track manual input values continuously so they're available at submit time
  var lastManualInput = '';
  function getQuestionScope() {
    var q = document.querySelector('[class*=QuestionWrapper]');
    if (!q || q.closest('#sparx-solver-box')) return null;
    return q;
  }
  function collectScopedAnswerParts(scope) {
    var parts = [];
    scope.querySelectorAll('input').forEach(function(inp) {
      if (inp.closest('#sparx-solver-box')) return;
      var t = (inp.type || '').toLowerCase();
      if (t === 'password' || t === 'hidden' || t === 'email' || t === 'tel' || t === 'search' || t === 'checkbox' || t === 'radio' || t === 'file') return;
      var ac = (inp.getAttribute('autocomplete') || '').toLowerCase();
      if (ac && /username|email|password|tel|one-time-code/.test(ac)) return;
      var v = (inp.value || '').trim();
      if (v) parts.push(v);
    });
    scope.querySelectorAll('select').forEach(function(sel) {
      if (sel.closest('#sparx-solver-box')) return;
      var o = sel.options[sel.selectedIndex];
      if (o && o.value) parts.push(o.textContent.trim());
    });
    return parts;
  }
  document.addEventListener('input', function(e) {
    try {
      if (autoFilling) return; // Don't track auto-fill typing as manual
      if (e.target.closest('#sparx-solver-box')) return;
      var scope = getQuestionScope();
      if (!scope) return; // not on a question page — don't capture login/search/etc.
      if (!scope.contains(e.target)) return;
      var parts = collectScopedAnswerParts(scope);
      if (parts.length) lastManualInput = parts.join(' | ');
    } catch(e) {}
  }, true);
  document.addEventListener('change', function(e) {
    try {
      if (autoFilling) return; // Don't track auto-fill changes as manual
      if (e.target.closest('#sparx-solver-box')) return;
      var scope = getQuestionScope();
      if (!scope) return;
      if (!scope.contains(e.target)) return;
      var parts = collectScopedAnswerParts(scope);
      if (parts.length) lastManualInput = parts.join(' | ');
    } catch(e) {}
  }, true);

  document.addEventListener('click', function(e) {
    try {
      if (isSummaryPage()) return;
      if (autoFilling) return;
      var scope = getQuestionScope();
      if (!scope) return; // not on a question page — don't save anything
      // Capture manual answers only on real submit-like buttons
      var btn = e.target.closest('[class*=_ButtonPrimary_], [class*=_ButtonBlue_], button');
      if (!btn) return;
      var btnText = (btn.innerText || '').trim().toLowerCase();
      // Require a submit-like label (or empty, for icon-only buttons). Otherwise skip —
      // this filters "Sign in", "Back", "Cancel", "Watch video", etc.
      if (btnText && !/^(submit|ok|done|next|check|continue|save|answer|finish)$/i.test(btnText) && !/\b(submit|check answer|save and continue)\b/i.test(btnText)) return;

      // Try EVERY method to read the current answer — always read fresh from DOM
      var parts = [];

      // Method 1: read actual <input> elements inside the question
      scope.querySelectorAll('input').forEach(function(inp) {
        if (inp.closest('#sparx-solver-box')) return;
        var t = (inp.type || '').toLowerCase();
        if (t === 'password' || t === 'hidden' || t === 'email' || t === 'tel' || t === 'search' || t === 'checkbox' || t === 'radio' || t === 'file') return;
        var v = (inp.value || '').trim();
        if (v) parts.push(v);
      });

      // Method 2: read _TextFieldNumeric_ and _TextField_ inputs specifically
      if (!parts.length) {
        scope.querySelectorAll('[class*=_TextFieldNumeric_] input, [class*=_TextField_] input').forEach(function(el) {
          if (el.closest('#sparx-solver-box')) return;
          var v = (el.value || '').trim();
          if (v) parts.push(v);
        });
      }

      // Method 3: read filled slots — cards placed inside slots (KaTeX content)
      if (!parts.length) {
        scope.querySelectorAll('[class*=_InlineSlot] [class*=_CardContent], [class*=_CardSlot] [class*=_CardContent], [class*=_Slot_] [class*=_CardContent]').forEach(function(el) {
          if (el.closest('#sparx-solver-box')) return;
          if (el.className.indexOf('_Empty') !== -1 || el.className.indexOf('_Placeholder') !== -1) return;
          var v = getOptionTextReadable(el);
          if (v) parts.push(v);
        });
      }

      // Method 4: read select dropdowns
      if (!parts.length) {
        scope.querySelectorAll('select').forEach(function(sel) {
          if (sel.closest('#sparx-solver-box')) return;
          var opt = sel.options[sel.selectedIndex];
          if (opt && opt.value) parts.push(opt.textContent.trim());
        });
      }

      // Method 5: fall back to saved input events
      var manualAnswer = '';
      if (parts.length) {
        manualAnswer = parts.join(' | ');
      } else if (lastManualInput) {
        manualAnswer = lastManualInput;
      }
      if (!manualAnswer) return;

      var codeEl = document.querySelector('[class*=_Selected_]');
      var code = codeEl ? codeEl.innerText.trim() : currentCode;
      if (!code || code === '?') return; // don't save entries with unknown bookwork code
      // Move to front (remove old, add new)
      for (var i=history.length-1;i>=0;i--){if(history[i].code===code)history.splice(i,1);}
      history.unshift({code:code, ans:manualAnswer, manual:true});
      if(history.length>40)history.pop();
      lastManualInput = '';
      saveHistory(); renderHist();
    } catch(e) {}
  }, true);

  document.addEventListener('keydown', function(e) {
    // Ignore synthetic keyboard events dispatched by our own code
    if (isSyntheticKey) return;
    var parts=[];
    if (e.ctrlKey) parts.push('Ctrl');
    if (e.altKey) parts.push('Alt');
    if (e.shiftKey) parts.push('Shift');
    if (!['Control','Alt','Shift','Meta'].includes(e.key)) parts.push(e.key.toUpperCase());
    if (parts.join('+')===sparxKeybind) { box.classList.toggle('open'); if (box.classList.contains('open')) scan(); e.preventDefault(); }
  });

  function isTimesTablePage() {
    var headings = document.querySelectorAll('h1, h2, h3, [class*=_Title_], [class*=_Header_], [class*=_Heading_]');
    for (var i = 0; i < headings.length; i++) {
      if (/times\s*tables?/i.test(headings[i].innerText)) return true;
    }
    if (/times.?tables?/i.test(location.href)) return true;
    return false;
  }

  function isSummaryPage() {
    // If a question is visible, it's definitely not a summary page
    var q = document.querySelector('[class*=QuestionWrapper]');
    if (q && !q.closest('#sparx-solver-box')) return false;
    return !!(
      document.querySelector('[class*=_TaskComplete_]') ||
      document.querySelector('[class*=_PackageComplete_]') ||
      document.querySelector('[class*=_CompletionScreen_]') ||
      document.querySelector('[class*=_Summary_]') ||
      document.querySelector('[class*=_Results_]')
    );
  }

  var bookworkDone=false; var bookworkChipSeen=false;

  function getBookworkBlocks() {
    // Try multiple selectors for the answer option blocks
    var selectors = [
      '[class*=_AnswerBlock]', '[class*=_answerBlock]', '[class*=_Answer_][class*=_Block]',
      '[class*=_BookworkAnswer]', '[class*=_Option_]', '.answer-block'
    ];
    for (var s = 0; s < selectors.length; s++) {
      var blocks = document.querySelectorAll(selectors[s]);
      var filtered = Array.from(blocks).filter(function(b) { return !b.closest('#sparx-solver-box'); });
      if (filtered.length > 1) return filtered;
    }
    // Fallback: look for clickable containers that look like answer choices
    var wrapper = document.querySelector('[class*=_Bookwork_]');
    if (wrapper) {
      var parent = wrapper.closest('[class*=_Question]') || wrapper.parentElement;
      if (parent) {
        var candidates = parent.querySelectorAll('[class*=_Card], [role="button"], [tabindex]');
        var filtered = Array.from(candidates).filter(function(c) {
          return c.innerText.trim().length > 0 && !c.closest('#sparx-solver-box');
        });
        if (filtered.length > 1) return filtered;
      }
    }
    return [];
  }

  function getBlockText(block) {
    // Try KaTeX annotation first for clean math
    var ann = block.querySelector('.katex-mathml annotation');
    if (ann && ann.textContent.trim()) return stripLatex(ann.textContent).trim();
    // Try aria-label
    var aria = block.getAttribute('aria-label') || '';
    if (aria.trim()) return aria.trim();
    // Fall back to innerText
    return block.innerText.trim();
  }

  function cleanForMatch(s) {
    return s.toLowerCase().replace(/\s+/g,'').replace(/[^a-z0-9.\/\+\-=]/g,'');
  }

  function checkForBookwork() {
    if (isSummaryPage()) return;
    var chip = document.querySelector('[class*=_Bookwork_]');
    if (!chip) { bookworkChipSeen=false; return; }
    if (!bookworkChipSeen) { bookworkChipSeen=true; bookworkDone=false; }
    if (bookworkDone) return;
    var blocks = getBookworkBlocks();
    if (!blocks.length) return;
    bookworkDone = true;
    var code = chip.innerText.trim().replace(/Bookwork/i,'').replace(/code/i,'').replace(/:/g,'').replace(/\s+/g,' ').trim();

    // Find saved answer for this code
    var saved = null;
    for (var i=0; i<history.length; i++) {
      if (history[i].code === code) { saved = history[i].ans; break; }
    }

    // Also check part-specific codes (e.g. "1D a)")
    if (!saved) {
      for (var i=0; i<history.length; i++) {
        if (history[i].code && history[i].code.indexOf(code) === 0) { saved = history[i].ans; break; }
      }
    }

    if (!saved) {
      // No saved answer — update panel to warn user
      var at = document.getElementById('sparx-answer-text');
      if (at) at.textContent = 'Bookwork check: ' + code + ' — no saved answer found!';
      bookworkDone = false;
      return;
    }

    var savedClean = cleanForMatch(saved);

    // Score each block
    var bestBlock=null; var bestScore=-1;
    blocks.forEach(function(block) {
      var blockText = getBlockText(block);
      var blockClean = cleanForMatch(blockText);
      var score=0;
      if (blockClean===savedClean) score=100;
      else if (blockClean.length>0 && savedClean.length>0) {
        // Check numeric equivalence (e.g. "5" matches "5.0")
        var blockNum = parseFloat(blockClean);
        var savedNum = parseFloat(savedClean);
        if (!isNaN(blockNum) && !isNaN(savedNum) && blockNum === savedNum) score=95;
        // Substring containment
        else if (savedClean.indexOf(blockClean)!==-1 && blockClean.length>0) score=50;
        else if (blockClean.indexOf(savedClean)!==-1 && savedClean.length>0) score=40;
        // Number-only comparison
        else {
          var blockNums = blockClean.replace(/[^0-9.\-\/]/g,'');
          var savedNums = savedClean.replace(/[^0-9.\-\/]/g,'');
          if (blockNums.length>0 && blockNums === savedNums) score=60;
        }
      }
      if (score>bestScore) { bestScore=score; bestBlock=block; }
    });

    if (bestBlock && bestScore > 0) {
      setTimeout(function() {
        sparxClick(bestBlock);
        setTimeout(function() {
          var submitBtn = document.querySelector('[class*=_ButtonPrimary_]');
          if (submitBtn) sparxClick(submitBtn);
          bookworkDone=false;
        }, 300);
      }, 300);
    } else {
      // Show what we had vs what options exist
      var optTexts = blocks.map(function(b) { return getBlockText(b); }).join(', ');
      var at = document.getElementById('sparx-answer-text');
      if (at) at.textContent = 'Bookwork ' + code + ': saved "' + saved + '" but no match in [' + optTexts + ']';
      bookworkDone = false;
    }
  }

  var lastQuestionText = '';
  var lastDetectedCode = '';

  setInterval(function() {
    try {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        bookworkDone = false;
        bookworkChipSeen = false;
        lastDetectedCode = '';
      }

      // Only detect new questions when the bookwork code changes
      if (!autoFilling) {
        var codeEl = document.querySelector('[class*=_Selected_]');
        var newCode = codeEl ? codeEl.innerText.trim() : '';

        if (newCode && newCode !== lastDetectedCode) {
          lastDetectedCode = newCode;
          currentCode = newCode;
          scan();
        }
      }

      checkForBookwork();
    } catch(e) {}
  }, 300);

  toggleBtn.addEventListener('click', function() { box.classList.toggle('open'); if (box.classList.contains('open')) scan(); });

  // Use event delegation on the box to avoid Sparx swallowing clicks
  box.addEventListener('click', function(e) {
    var target = e.target;
    // Click-to-expand question text
    if (target.id === 'sparx-q-display') { e.stopPropagation(); target.classList.toggle('expanded'); return; }
    if (target.id === 'sparx-scan-btn') { e.stopPropagation(); scan(); }
    else if (target.id === 'sparx-solve-btn') { e.stopPropagation(); solve(); }
    else if (target.id === 'sparx-autofill-btn') { e.stopPropagation(); startAutoFill(); }
    else if (target.id === 'sparx-hist-toggle') {
      e.stopPropagation();
      var h=document.getElementById('sparx-history');
      h.classList.toggle('open'); target.textContent=h.classList.contains('open')?'Hide history':'Show history';
      var clearBtn=document.getElementById('sparx-hist-clear');
      if(clearBtn) clearBtn.style.display=h.classList.contains('open')&&history.length?'block':'none';
    }
    else if (target.id === 'sparx-hist-clear') {
      e.stopPropagation();
      history=[]; saveHistory(); renderHist();
      target.style.display='none';
    }
  }, true);

  function scan() {
    if (autoFilling) return;
    var d=document.getElementById('sparx-q-display');
    if (isTimesTablePage()) {
      d.textContent='Do your times tables, kids!'; d.classList.add('has-text');
      document.getElementById('sparx-solve-btn').disabled=true;
      document.getElementById('sparx-autofill-btn').disabled=true;
      document.getElementById('sparx-answer-box').classList.remove('visible');
      return;
    }
    currentImageB64=null; currentGraphB64=null; hasRealImage=false; currentTranscript=''; inputBoxCount=0; cardChoices=[];
    var codeEl=document.querySelector('[class*=_Selected_]');
    currentCode = codeEl ? codeEl.innerText.trim() : '?';
    var exact=document.querySelector('[class*=QuestionWrapper]');
    if (exact&&!exact.closest('#sparx-solver-box')) {
      currentQuestion = extractCleanQuestion(exact);
      lastQuestionText = currentQuestion.substring(0,200);
      hasRealImage = hasQuestionMedia(exact);
      inputBoxCount = getNumericInputs().length;
      d.textContent='Rendering question...'; d.classList.add('has-text');
      if (hasRealImage) {
        fetchTranscript(function(transcript) { currentTranscript = transcript; });
        var graphImg = findQuestionImage(exact);
        if (graphImg && graphImg.src) {
          fetchImageAsB64(graphImg.src, function(b64) { if (b64) currentGraphB64 = b64; });
        }
      }
      var scanScale = hasRealImage ? 2 : 1.2;
      html2canvas(exact,{backgroundColor:'#ffffff',scale:scanScale,useCORS:true,logging:false})
      .then(function(canvas){
        var trimmed = trimCanvas(canvas);
        currentImageB64=trimmed.toDataURL('image/png').split(',')[1];
        var qText = currentQuestion+(hasRealImage?' [image]':'')+(currentGraphB64?' [graph]':'')+(currentTranscript?' [transcript]':'');
        d.textContent=qText;
        d.classList.add('has-text');
        d.classList.remove('expanded');
        if (qText.length < 100) d.classList.add('short-text');
        else d.classList.remove('short-text');
        document.getElementById('sparx-solve-btn').disabled=false;
        document.getElementById('sparx-autofill-btn').disabled=false;
        document.getElementById('sparx-answer-box').classList.remove('visible');
        document.getElementById('sparx-answer-text').innerHTML='';
      }).catch(function(){
        d.textContent=currentQuestion;
        document.getElementById('sparx-solve-btn').disabled=false;
        document.getElementById('sparx-autofill-btn').disabled=false;
      });
    } else {
      d.textContent='No question found. Click inside the question on the page, then scan again.';
    }
  }

  function fetchTranscript(callback) {
    var track = document.querySelector('track[kind="subtitles"]');
    if (!track) { callback(''); return; }
    var src = track.getAttribute('src');
    if (!src) { callback(''); return; }
    fetch(src)
      .then(function(r) { return r.text(); })
      .then(function(vtt) {
        var text = vtt.split('\n')
          .filter(function(l){ return l.trim() && !l.startsWith('WEBVTT') && !l.match(/^\d+$/) && !l.match(/[\d:]+\s*-->/); })
          .join(' ').replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim()
          .split(' ').slice(0,400).join(' ');
        callback(text);
      })
      .catch(function(){ callback(''); });
  }

  function fetchImageAsB64(url, callback) {
    fetch(url)
      .then(function(r){ return r.blob(); })
      .then(function(blob){
        var reader = new FileReader();
        reader.onloadend = function(){ callback(reader.result.split(',')[1]); };
        reader.readAsDataURL(blob);
      })
      .catch(function(){ callback(null); });
  }

  function saveDevInfo(modelUsed) {
    var devInfo = {model:modelUsed, hasImage:hasRealImage, code:currentCode};
    var mediaInfo = extractMediaInfo();
    if (mediaInfo) devInfo.mediaInfo = mediaInfo;
    chrome.storage.local.set({sparxDevInfo: devInfo});
  }

  function done(btn){btn.disabled=false;btn.textContent='Solve with AI';}

  function solve() {
    if (isTimesTablePage() || !currentQuestion) return;
    var btn=document.getElementById('sparx-solve-btn'); var ab=document.getElementById('sparx-answer-box'); var at=document.getElementById('sparx-answer-text');
    btn.disabled=true; btn.textContent=loadingText; ab.classList.add('visible'); at.className='sparx-answer-text loading'; at.textContent=loadingText;

    function doSolve() {
      chrome.storage.local.get(['sparxApiKey','sparxModel'],function(data){
        if (!data.sparxApiKey){at.className='sparx-answer-text';at.textContent='No API key! Click the Sparx Solver icon in your toolbar.';done(btn);return;}
        var model=data.sparxModel||'groq';
        if (hasRealImage&&model==='groq'){at.className='sparx-answer-text';at.textContent='Image questions require Anthropic or Gemini.';done(btn);return;}

        callAI(data.sparxApiKey, model, function(a, modelUsed) {
          at.className='sparx-answer-text';
          renderMarkdown(a,at);
          currentAnswer=extractShortAnswer(a);
          for(var i=history.length-1;i>=0;i--){if(history[i].code===currentCode)history.splice(i,1);}
          history.unshift({code:currentCode,ans:currentAnswer,full:a});
          if(history.length>40)history.pop();
          // Save each part as separate history entries
          savePartAnswers(a);
          saveHistory();renderHist();saveDevInfo(modelUsed);done(btn);
        }, function(e){at.className='sparx-answer-text';at.textContent=errorText+': '+e.message;done(btn);});
      });
    }

    // Take a fresh screenshot before solving (don't rely on scan's async capture)
    var exact=document.querySelector('[class*=QuestionWrapper]');
    if (exact && !exact.closest('#sparx-solver-box') && hasRealImage) {
      var graphImg = findQuestionImage(exact);
      if (graphImg && graphImg.src) {
        fetchImageAsB64(graphImg.src, function(b64) { if (b64) currentGraphB64 = b64; });
      }
      html2canvas(exact,{backgroundColor:'#ffffff',scale:2,useCORS:true,logging:false})
      .then(function(canvas){
        var trimmed = trimCanvas(canvas);
        currentImageB64 = trimmed.toDataURL('image/png').split(',')[1];
        doSolve();
      }).catch(function(){ doSolve(); });
    } else {
      if (!hasRealImage) currentImageB64 = null;
      doSolve();
    }
  }

  function renderHist() {
    var h=document.getElementById('sparx-history');
    if(!history.length){h.innerHTML='';return;}
    var html='';
    history.forEach(function(x,i){
      var tag=x.manual?'<span style="color:#4caf7a;font-size:10px;margin-left:4px;">✎</span>':'';
      var hasMore=!!(x.full&&x.full!==x.ans);
      html+='<div class="sparx-hist-item">'
        +'<div class="sparx-label">'+esc(x.code)+tag+'</div>'
        +'<div class="sparx-hist-md" data-short="'+esc(x.ans||'')+'" data-full="'+esc(x.full||x.ans||'')+'" data-expanded="0"></div>'
        +(hasMore?'<span class="sparx-hist-more">more</span>':'')
        +'</div>';
    });
    h.innerHTML=html;
    h.querySelectorAll('.sparx-hist-md').forEach(function(el){
      renderMarkdown(el.dataset.short, el);
    });
    h.querySelectorAll('.sparx-hist-more').forEach(function(btn){
      btn.addEventListener('click', function(){
        var md=btn.previousElementSibling;
        if(md.dataset.expanded==='0'){
          renderMarkdown(md.dataset.full, md);
          md.dataset.expanded='1';
          btn.textContent='less';
        } else {
          renderMarkdown(md.dataset.short, md);
          md.dataset.expanded='0';
          btn.textContent='more';
        }
      });
    });
  }

  function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
})();

