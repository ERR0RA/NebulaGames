(function(){
  var o = window.btoa;
  window.btoa = function(s) {
    try { return o(s); } catch(e) {
      return o(unescape(encodeURIComponent(s)));
    }
  };
})();
